CREATE DATABASE  IF NOT EXISTS `finance` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `finance`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: finance
-- ------------------------------------------------------
-- Server version	5.7.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acl`
--

DROP TABLE IF EXISTS `acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acl` (
  `acl_id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(45) DEFAULT NULL,
  `controller` varchar(45) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`acl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COMMENT='Permissions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl`
--

LOCK TABLES `acl` WRITE;
/*!40000 ALTER TABLE `acl` DISABLE KEYS */;
INSERT INTO `acl` VALUES (1,'master','auth','index',0),(2,'master','auth','login',0),(3,'master','auth','logout',0),(4,'master','home','index',0),(5,'donate','get','index',0),(6,'donate','pin','index',0),(7,'donate','provide','index',0),(8,'gui','template','index',0),(9,'gui','template','login',0),(10,'gui','template','dashboard',0),(11,'gui','template','register',0),(12,'gui','template','providehelp',0),(13,'gui','template','gethelp',0),(14,'gui','template','transferlist',0),(15,'gui','template','createph',0),(16,'gui','template','creategh',0),(17,'gui','template','message',0),(18,'gui','template','commission',0),(19,'gui','template','pin',0),(20,'gui','template','referral',0),(21,'gui','template','pintransfer',0),(22,'gui','template','history',0),(23,'gui','template','downlinetree',0),(24,'gui','template','notification',0),(25,'gui','template','transferinfo',0),(26,'gui','template','help',0),(27,'gui','template','profile',0),(28,'master','pin','index',0),(29,'master','pin','table',0),(30,'master','pin','pintransfer',0),(31,'master','pin','save',0),(32,'master','register','index',0),(33,'master','register','save',0),(34,'master','auth','profile',0),(35,'master','auth','updateaccount',0),(36,'master','auth','updatepassword',0),(37,'master','auth','updatetpassword',0),(38,'master','auth','updatebank',0),(39,'master','dashboard','index',0),(40,'master','home','table',0),(41,'master','home','howitworks',0),(42,'master','home','contact',0),(43,'master','message','index',0),(44,'master','message','table',0),(45,'master','message','save',0),(46,'master','message','delete',0),(47,'master','message','create',0),(48,'master','news','index',0),(49,'master','news','table',0),(50,'master','news','save',0),(51,'master','news','create',0),(52,'master','news','howitworks',0),(53,'master','news','savehowitworks',0),(54,'master','notification','index',0),(55,'master','notification','table',0),(56,'master','notification','save',0),(57,'master','notification','create',0),(58,'master','tree','referral',0),(59,'master','tree','downlinetree',0);
/*!40000 ALTER TABLE `acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_to_role`
--

DROP TABLE IF EXISTS `acl_to_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acl_to_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acl_id` int(11) DEFAULT NULL,
  `role_id` int(2) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COMMENT='acl_to_roles';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_to_role`
--

LOCK TABLES `acl_to_role` WRITE;
/*!40000 ALTER TABLE `acl_to_role` DISABLE KEYS */;
INSERT INTO `acl_to_role` VALUES (2,1,1,1,0),(3,1,2,1,0),(4,1,3,1,0),(5,2,1,1,0),(6,2,2,1,0),(7,2,3,1,0),(8,3,1,1,0),(9,3,2,1,0),(10,3,3,1,0),(11,4,1,1,0),(12,4,2,1,0),(13,4,3,1,0),(14,5,1,1,0),(15,5,2,1,0),(16,5,3,1,0),(17,6,1,1,0),(18,6,2,1,0),(19,6,3,1,0),(20,7,1,1,0),(21,7,2,1,0),(22,7,3,1,0),(23,8,1,1,0),(24,8,2,1,0),(25,8,3,1,0),(26,9,1,1,0),(27,9,2,1,0),(28,9,3,1,0),(29,10,1,1,0),(30,10,2,1,0),(31,10,3,1,0),(32,11,1,1,0),(33,11,2,1,0),(34,11,3,1,0),(35,12,1,1,0),(36,12,2,1,0),(37,12,3,1,0),(38,13,1,1,0),(39,13,2,1,0),(40,13,3,1,0),(41,14,1,1,0),(42,14,2,1,0),(43,14,3,1,0),(44,15,1,1,0),(45,15,2,1,0),(46,15,3,1,0),(47,16,1,1,0),(48,16,2,1,0),(49,16,3,1,0),(50,17,1,1,0),(51,17,2,1,0),(52,17,3,1,0),(53,18,1,1,0),(54,18,2,1,0),(55,18,3,1,0),(56,19,1,1,0),(57,19,2,1,0),(58,19,3,1,0),(59,20,1,1,0),(60,20,2,1,0),(61,20,3,1,0),(62,21,1,1,0),(63,21,2,1,0),(64,21,3,1,0),(65,22,1,1,0),(66,22,2,1,0),(67,22,3,1,0),(68,23,1,1,0),(69,23,2,1,0),(70,23,3,1,0),(71,24,1,1,0),(72,24,2,1,0),(73,24,3,1,0),(74,25,1,1,0),(75,25,2,1,0),(76,25,3,1,0),(77,26,1,1,0),(78,26,2,1,0),(79,26,3,1,0),(80,27,1,1,0),(81,27,2,1,0),(82,27,3,1,0),(83,28,1,1,0),(84,28,2,1,0),(85,28,3,1,0),(86,29,1,1,0),(87,29,2,1,0),(88,29,3,1,0),(89,30,1,1,0),(90,30,2,1,0),(91,30,3,1,0),(92,31,1,1,0),(93,31,2,1,0),(94,31,3,1,0),(95,32,1,1,0),(96,32,2,1,0),(97,32,3,1,0),(98,33,1,1,0),(99,33,2,1,0),(100,33,3,1,0);
/*!40000 ALTER TABLE `acl_to_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `btc001`
--

DROP TABLE IF EXISTS `btc001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `btc001` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `btc_address` varchar(100) DEFAULT NULL,
  `btc_label` varchar(255) DEFAULT NULL,
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COMMENT='wallet of bitcoin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `btc001`
--

LOCK TABLES `btc001` WRITE;
/*!40000 ALTER TABLE `btc001` DISABLE KEYS */;
INSERT INTO `btc001` VALUES (1,1,'1LXi4ZnDRLdZQX5mfzP8cYv6ac6JGzPy9d','admin','127.0.0.1',NULL,NULL,NULL,NULL,NULL,0),(2,2,'1KYKEQ84cvvJRZyFdV6M9H3UpYdkh4HkUs','guest','127.0.0.1',NULL,NULL,NULL,NULL,NULL,0),(40,46,'1CDf82gaPEnwaPaWSmGdx9JMkg4YhYzjY5','Larybc','42.116.94.141',NULL,NULL,NULL,NULL,NULL,0),(41,49,'13BB2miAWMSQMXrqymN2KMJDoY8Fiom9sy',NULL,'127.0.0.1',NULL,NULL,NULL,NULL,NULL,0),(42,57,'1Np3wRgnqN4xek27XT3YzZ4oZeNaRg95Cn','Martin','59.153.232.130',NULL,NULL,NULL,NULL,NULL,0),(43,58,'1QAssNDc1miJFmqATmVizGP5skwPraWx26','Alain','59.153.235.131',NULL,NULL,NULL,NULL,NULL,0),(44,59,'13stu38GDnGB7HbHMqRHLw7FZ7CQLuh2ZY','Eaglebc','59.153.235.131',NULL,NULL,NULL,NULL,NULL,0),(45,60,'1AyyotHC2ZMkATqyVnVS2BeuwW43R7cNuU','Tiger','59.153.235.131',NULL,NULL,NULL,NULL,NULL,0),(46,61,'1M1xtqPnXvqSvaQgaNnZYc3ADSW4AqFsEw','Mavella','59.153.235.131',NULL,NULL,NULL,NULL,NULL,0),(47,62,'12SQwK5ZrdvuVh8RbhBo8rXCs3dMFBwAWk','Snehal','59.153.235.131',NULL,NULL,NULL,NULL,NULL,0),(48,63,'1GNnM1APT7L28SA1jL1z8JX8Y46MyK1cv6','dnloc83','123.16.0.192',NULL,NULL,NULL,NULL,NULL,0),(49,64,'1LGp8qXiFNWq69XnkWLnpuWxfbaYY5Nap7','Hungbc','59.153.235.131',NULL,NULL,NULL,NULL,NULL,0),(50,65,'1AgbsscLPD328B9y1KWE5gBBXb3sqsn9sV','Blienbitcoin','59.153.232.13',NULL,NULL,NULL,NULL,NULL,0),(51,66,'13uJAChSdmfysKFSkpBrPKhhEaCvBQuBhE','Rosemary','59.153.232.13',NULL,NULL,NULL,NULL,NULL,0),(52,67,'15TBFpa6AvjqgRijU1Jb4oNWWk9aN7qqFE','Chalie','59.153.240.231',NULL,NULL,NULL,NULL,NULL,0),(53,68,'15i2TJGa8yUCihMnV3cAtv5ER5ncN5nq4s','Bigson','59.153.240.231',NULL,NULL,NULL,NULL,NULL,0),(54,69,'1ETph1FzadvBZyez9o1KB96eDRwHSBpFC3','Hk01','59.153.240.231',NULL,NULL,NULL,NULL,NULL,0),(55,70,'1PcsFHn6HtHfnBz14psCibC88cZf66phQ4','Topbc','59.153.240.231',NULL,NULL,NULL,NULL,NULL,0),(56,71,'1Dr4J92o9Ji1WNEkDCeZ3BYpW5vxXUkEB2','admin001','123.27.11.116',NULL,NULL,NULL,NULL,NULL,0),(57,72,'1w94VdFBZGzBWU1uymhUQUat8GSrWLYaJ','admin002','123.27.11.116',NULL,NULL,NULL,NULL,NULL,0),(58,73,'1CBxNe7touMjpdBDa71HBKcKBmpJLPBiLk','admin02','123.27.11.116',NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `btc001` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `d001`
--

DROP TABLE IF EXISTS `d001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `d001` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) DEFAULT NULL,
  `amount` decimal(15,8) NOT NULL,
  `status` varchar(45) NOT NULL,
  `get_profit_date` datetime DEFAULT NULL,
  `rate` decimal(10,4) DEFAULT '0.0000',
  `max_rate` varchar(45) DEFAULT NULL,
  `save_bit_rate` varchar(45) DEFAULT '0',
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='provide donate';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `d001`
--

LOCK TABLES `d001` WRITE;
/*!40000 ALTER TABLE `d001` DISABLE KEYS */;
INSERT INTO `d001` VALUES (1,2,1,0.90000000,'2','2016-10-14 19:10:46',0.8000,'124.0000','0.5','127.0.0.1','2016-09-14 19:10:46',NULL,NULL,NULL,NULL,0),(2,2,2,2.00000000,'2','2016-10-14 19:23:37',1.0000,'130','0.5','127.0.0.1','2016-09-18 01:23:37',NULL,NULL,NULL,NULL,0),(3,1,1,0.10000000,'2','2016-10-18 04:04:21',0.8000,'124.0000','0.5','116.107.221.33','2016-09-18 04:04:21',NULL,NULL,NULL,NULL,0),(4,1,1,0.10000000,'2','2016-10-18 04:25:45',0.8000,'124.0000','0.5','116.107.221.33','2016-09-18 04:25:45',NULL,NULL,NULL,NULL,0),(5,1,1,0.10000000,'2','2016-10-18 04:25:50',0.8000,'124.0000','0.5','116.107.221.33','2016-09-18 04:25:50',NULL,NULL,NULL,NULL,0),(6,46,1,0.10000000,'1','2016-10-18 14:30:04',0.8000,'124.0000','0.5','59.153.235.214','2016-09-18 14:30:04',NULL,NULL,NULL,NULL,0),(7,63,1,0.10000000,'1','2016-10-22 12:47:14',0.8000,'124.0000','0.5','123.16.24.86','2016-09-22 12:47:14',NULL,NULL,NULL,NULL,0),(8,1,1,0.90000000,'1','2016-12-25 12:30:41',0.8000,'124.0000','0.5','192.168.1.24','2016-11-25 12:30:41',NULL,NULL,NULL,NULL,0),(9,1,1,0.10000000,'1','2016-12-25 13:43:48',0.8000,'124.0000','0.5','192.168.1.24','2016-11-25 13:43:48',NULL,NULL,NULL,NULL,0),(10,1,1,0.10000000,'1','2016-12-25 13:47:39',0.8000,'124.0000','0.5','192.168.1.24','2016-11-25 13:47:39',NULL,NULL,NULL,NULL,0),(11,1,1,0.80000000,'1','2016-12-28 19:53:54',0.8000,'124.0000','0.5','127.0.0.1','2016-11-28 19:53:54',NULL,NULL,NULL,NULL,0),(12,1,2,1.00000000,'1','2016-12-28 13:47:44',1.0000,'130','0.5','42.114.47.218','2016-11-28 13:47:44',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `d001` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `d002`
--

DROP TABLE IF EXISTS `d002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `d002` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(15,8) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='get donate';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `d002`
--

LOCK TABLES `d002` WRITE;
/*!40000 ALTER TABLE `d002` DISABLE KEYS */;
INSERT INTO `d002` VALUES (1,46,0.00100000,'2','59.153.240.4','2016-11-23 06:30:34',NULL,NULL,NULL,NULL,0),(2,57,0.00100000,'2','59.153.240.4','2016-11-23 06:30:34',NULL,NULL,NULL,NULL,0),(4,1,0.34426668,'2','192.168.1.24','2016-11-26 04:46:19',NULL,NULL,NULL,NULL,0),(5,1,0.24000000,'2','192.168.1.24','2016-11-26 04:53:02',NULL,NULL,NULL,NULL,0),(6,1,0.31825332,'2','192.168.1.24','2016-11-26 04:54:07',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `d002` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_history`
--

DROP TABLE IF EXISTS `job_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_history` (
  `type_job` varchar(50) NOT NULL,
  `date_run` datetime NOT NULL,
  PRIMARY KEY (`type_job`),
  UNIQUE KEY `type_UNIQUE` (`type_job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='history job';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_history`
--

LOCK TABLES `job_history` WRITE;
/*!40000 ALTER TABLE `job_history` DISABLE KEYS */;
INSERT INTO `job_history` VALUES ('job_update','2016-12-23 00:00:02');
/*!40000 ALTER TABLE `job_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lib001`
--

DROP TABLE IF EXISTS `lib001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lib001` (
  `code` varchar(45) NOT NULL,
  `value_id` int(11) NOT NULL,
  `value` varchar(45) DEFAULT NULL,
  `lang_id` tinyint(1) DEFAULT '1',
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_update_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`code`,`value_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='library system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lib001`
--

LOCK TABLES `lib001` WRITE;
/*!40000 ALTER TABLE `lib001` DISABLE KEYS */;
INSERT INTO `lib001` VALUES ('rank',0,'BC0',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('rank',1,'BC1',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('rank',2,'BC2',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('rank',3,'BC3',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('rank',4,'BC4',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('rank',5,'BC5',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('report_help',1,'success',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('report_help',2,'watting',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('report_help',3,'unsuccessful',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_acc',1,'active',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_acc',2,'freeze',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_acc',3,'band',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_dnt_gh',1,'watting',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_dnt_gh',2,'finish',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_dnt_ph',1,'donated',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_dnt_ph',2,'finish',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_msg',1,'new',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_msg',2,'read',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('status_msg',3,'send',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('type_donate',1,'Deposit',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('type_donate',2,'Withdraw',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('type_pin',1,'tranfer send',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('type_pin',2,'tranfer receive',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('type_pin',3,'Withdraw',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('type_pin',4,'Deposit',1,NULL,NULL,NULL,NULL,NULL,NULL,0),('type_pin',5,'system tranfer',1,NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `lib001` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lib002`
--

DROP TABLE IF EXISTS `lib002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lib002` (
  `bank_id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) NOT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='master bank';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lib002`
--

LOCK TABLES `lib002` WRITE;
/*!40000 ALTER TABLE `lib002` DISABLE KEYS */;
/*!40000 ALTER TABLE `lib002` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_table_name`
--

DROP TABLE IF EXISTS `log_table_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_table_name` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lvl` int(11) DEFAULT NULL,
  `msg` longtext,
  `timestampFormat` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_table_name`
--

LOCK TABLES `log_table_name` WRITE;
/*!40000 ALTER TABLE `log_table_name` DISABLE KEYS */;
INSERT INTO `log_table_name` VALUES (9,6,'\"tcp        0      0 45.32.255.50:3000           0.0.0.0:*                   LISTEN      11321/node          \n\"','2016-12-10T21:53:01+07:00'),(10,6,'\"tcp        0      0 45.32.255.50:3000           0.0.0.0:*                   LISTEN      11321/node          \n\"','2016-12-10T21:53:33+07:00'),(11,6,'\"tcp        0      0 45.32.255.50:3000           0.0.0.0:*                   LISTEN      11321/node          \n\"','2016-12-10T21:54:01+07:00'),(12,6,'\"tcp        0      0 45.32.255.50:3000           0.0.0.0:*                   LISTEN      11321/node          \n\"','2016-12-10T21:55:01+07:00'),(13,6,'\"tcp        0      0 45.32.255.50:3000           0.0.0.0:*                   LISTEN      11321/node          \n\"','2016-12-10T21:56:01+07:00'),(14,6,'\"tcp        0      0 45.32.255.50:3000           0.0.0.0:*                   LISTEN      11321/node          \n\"','2016-12-10T21:57:01+07:00'),(15,6,'\"tcp        0      0 45.32.255.50:3000           0.0.0.0:*                   LISTEN      11321/node          \n\"','2016-12-10T21:58:02+07:00'),(16,6,'\"tcp        0      0 45.32.255.50:3000           0.0.0.0:*                   LISTEN      11321/node          \n\"','2016-12-10T21:59:01+07:00'),(17,6,'\"1481380263837 - warn: WARNING - Binding this service to any ip other than localhost (127.0.0.1) can lead to security vulnerabilities!\n1481380263846 - info: blockchain.info wallet service v0.21.3 running on http://45.32.255.50:3000\n\"','2016-12-10T21:59:41+07:00'),(20,6,'{}','2016-12-11T07:00:04+07:00'),(21,6,'{}','2016-12-12T07:00:03+07:00'),(22,6,'{}','2016-12-13T07:00:03+07:00'),(23,6,'{}','2016-12-14T07:00:04+07:00'),(24,6,'{}','2016-12-15T07:00:04+07:00'),(25,6,'{}','2016-12-16T07:00:03+07:00'),(26,6,'{}','2016-12-17T07:00:03+07:00'),(27,6,'{}','2016-12-18T07:00:05+07:00'),(28,6,'{}','2016-12-19T07:00:03+07:00'),(29,6,'{}','2016-12-20T07:00:04+07:00'),(30,6,'{}','2016-12-21T07:00:04+07:00'),(31,6,'{}','2016-12-22T07:00:03+07:00'),(32,6,'{}','2016-12-23T07:00:04+07:00');
/*!40000 ALTER TABLE `log_table_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m001`
--

DROP TABLE IF EXISTS `m001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m001` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(200) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `parent_user_id` int(11) DEFAULT NULL,
  `wallet` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `t_password` varchar(200) DEFAULT NULL COMMENT 'transaction password',
  `role_id` tinyint(1) DEFAULT NULL COMMENT 'permission : admin, member...',
  `rank` tinyint(1) DEFAULT NULL COMMENT 'rank1,rank2,..rank5',
  `sex` tinyint(1) DEFAULT '1',
  `status` varchar(45) DEFAULT NULL,
  `reset_pass_code` varchar(45) DEFAULT NULL,
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) unsigned DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COMMENT='table users';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m001`
--

LOCK TABLES `m001` WRITE;
/*!40000 ALTER TABLE `m001` DISABLE KEYS */;
INSERT INTO `m001` VALUES (1,'admin',NULL,NULL,'16cEBZEt49SYFKhf2Qv1HrtVjLDTyTLg9k','hungbop68@gmail.com','+142332568966','dff029ff85e1a33f79b1cf1514d36e10','dff029ff85e1a33f79b1cf1514d36e10',3,0,1,'1',NULL,NULL,NULL,NULL,'127.0.0.1','2016-12-24 21:46:13','1',0),(2,'MarkLarry','Mark Larry',1,'16cEBZEt49SYFKhf2Qv1HrtVjLDTyTLg9k','hungbop68@gmail.com','+16868633882','dff029ff85e1a33f79b1cf1514d36e10','dff029ff85e1a33f79b1cf1514d36e10',1,0,1,'1',NULL,NULL,NULL,NULL,'59.153.235.214','2016-09-18 14:21:19','2',0),(46,'Larybc','Larry ',2,'16cEBZEt49SYFKhf2Qv1HrtVjLDTyTLg9k','larry19577@gmail.com','+1246895432','dff029ff85e1a33f79b1cf1514d36e10','dff029ff85e1a33f79b1cf1514d36e10',1,0,1,'1',NULL,'42.116.94.141','2016-09-12 02:30:35',NULL,'78.34.22.16','2016-12-21 18:29:48','46',0),(57,'Martin','Martin',46,'1LhzAW83pHVFh6AY9TVeh6Qn9oGAivmtXB','hungbop682@gmail.com','+35423454689','a30d9657f37d13de236268812a34e761','61412afb942980632b96ab94265c2495',1,0,1,'1',NULL,'59.153.232.130','2016-09-15 17:30:11',NULL,'59.153.232.12','2016-09-22 04:26:05',NULL,0),(58,'Alain','Alain',2,'1LhzAW83pHVFh6AY9TVeh6Qn9oGAivmtXB','hungbop686@gmail.com','+333562781934','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.235.131','2016-09-15 23:50:38',NULL,NULL,NULL,NULL,0),(59,'Eaglebc','Eagle',2,'1LhzAW83pHVFh6AY9TVeh6Qn9oGAivmtXB','hungbop683@gmail.com','+4917682242240','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.235.131','2016-09-15 23:54:59',NULL,NULL,NULL,NULL,0),(60,'Tiger','Tiger',2,'1LhzAW83pHVFh6AY9TVeh6Qn9oGAivmtXB','hungbop684@gmail.com','+7143256885322','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.235.131','2016-09-16 00:00:18',NULL,'59.153.232.223','2016-09-18 02:53:04',NULL,0),(61,'Mavella','Mavella',2,'1LhzAW83pHVFh6AY9TVeh6Qn9oGAivmtXB','nhk_74@yahoo.com','+365435214576','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.235.131','2016-09-16 00:04:11',NULL,NULL,NULL,NULL,0),(62,'Snehal','Snahal',2,'1LhzAW83pHVFh6AY9TVeh6Qn9oGAivmtXB','hungnguyentrung74@gmail.com','+6143526812467','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.235.131','2016-09-16 00:07:31',NULL,NULL,NULL,NULL,0),(63,'dnloc83','Dang Ngoc Loc',46,'1557Y96WHTqevzFTtd6DsLqwbY7E3iVvsa','dnloc83@gmail.com','0967736463','26601b5318d8052177f09c82d121246a','26601b5318d8052177f09c82d121246a',1,0,1,'1',NULL,'123.16.0.192','2016-09-16 00:09:10',NULL,'123.16.26.38','2016-10-07 22:49:36','63',0),(64,'Hungbc','Hung nguyen',63,'1LhzAW83pHVFh6AY9TVeh6Qn9oGAivmtXB','hungbop688@gmail.com','+84943583381','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.235.131','2016-09-16 02:45:09',NULL,'59.153.235.131','2016-09-16 02:45:45',NULL,0),(65,'Blienbitcoin','Blien oudin',46,'1MLgPAdhJJndZYJbd5b1vQGzbp8FnnZ8mZ','blienoudin@gmail.com','+1896657483346','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.232.13','2016-09-25 14:21:55',NULL,NULL,NULL,NULL,0),(66,'Rosemary','Mary',46,'1MLgPAdhJJndZYJbd5b1vQGzbp8FnnZ8mZ','maryrose@gmail.com','+33765498667','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.232.13','2016-09-25 14:23:20',NULL,NULL,NULL,NULL,0),(67,'Chalie','Chalie',46,'12kLG8HSpHmxJF3wPjrXYWg86KbFtj1Qj9','chaliebc66@gmail.com','+357632567867','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.240.231','2016-09-26 11:59:38',NULL,NULL,NULL,NULL,0),(68,'Bigson','Laura',46,'12kLG8HSpHmxJF3wPjrXYWg86KbFtj1Qj9','lauracb86@gmail.com','+36543265784','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.240.231','2016-09-26 12:02:07',NULL,NULL,NULL,NULL,0),(69,'Hk01','Nghia nguyen',63,'12kLG8HSpHmxJF3wPjrXYWg86KbFtj1Qj9','duongbitcoin@yahoo.com','004988','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.240.231','2016-09-26 12:08:11',NULL,NULL,NULL,NULL,0),(70,'Topbc','Tina',2,'12kLG8HSpHmxJF3wPjrXYWg86KbFtj1Qj9','tinabitbc@gmail.com','+34256432666','a30d9657f37d13de236268812a34e761','a30d9657f37d13de236268812a34e761',1,0,1,'1',NULL,'59.153.240.231','2016-09-26 14:48:08',NULL,NULL,NULL,NULL,0),(71,'admin001','test001',1,'123123','giang2b@gmail.com','1212121212','dff029ff85e1a33f79b1cf1514d36e10',NULL,1,0,1,'1',NULL,'123.27.11.116','2016-12-03 04:54:12',NULL,'123.27.11.116','2016-12-03 04:54:48',NULL,0),(72,'admin002','test111',71,'123123','giangnta2b@gmail.com','9876552342','dff029ff85e1a33f79b1cf1514d36e10',NULL,1,0,1,'1',NULL,'123.27.11.116','2016-12-03 05:18:32',NULL,NULL,NULL,NULL,0),(73,'admin02','afa',71,'123','asdfa22@gmail.com','3423423423','dff029ff85e1a33f79b1cf1514d36e10',NULL,1,0,1,'1',NULL,'123.27.11.116','2016-12-03 05:23:26',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `m001` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m002`
--

DROP TABLE IF EXISTS `m002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m002` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(200) DEFAULT NULL COMMENT 'ten goi ph',
  `start` varchar(45) DEFAULT NULL,
  `end` varchar(45) DEFAULT NULL,
  `distance` varchar(45) DEFAULT NULL,
  `rate` decimal(10,4) DEFAULT '0.0000',
  `interest_rate` varchar(45) DEFAULT '0',
  `max_rate` varchar(45) DEFAULT NULL,
  `save_bit_rate` varchar(45) DEFAULT '0',
  `allow_bit_rate` varchar(45) DEFAULT '0',
  `pin_cost` varchar(45) DEFAULT NULL COMMENT 'so pin cho goi ph',
  `pin_cost_gh` int(11) DEFAULT '0',
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='package for ph';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m002`
--

LOCK TABLES `m002` WRITE;
/*!40000 ALTER TABLE `m002` DISABLE KEYS */;
INSERT INTO `m002` VALUES (1,'Basic','0.1','0.9','0.1',0.8000,'4.140000000','124.0000','0.5','0.740000000','1',1,NULL,NULL,NULL,NULL,NULL,NULL,0),(2,'Standard','1','3','1',1.0000,'4.34','130','0.5','0.8','2',1,NULL,NULL,NULL,NULL,NULL,NULL,0),(3,'PRO','4','5','1',1.0000,'4.34','130','0.5','0.8','3',1,NULL,NULL,NULL,NULL,NULL,NULL,0),(4,'VIP','6','7','1',1.0000,'4.34','130','0.5','0.8','5',1,NULL,NULL,NULL,NULL,NULL,NULL,0),(5,'PLUS','8','10','1',1.0000,'4.34','130','0.5','0.8','6',1,NULL,NULL,NULL,NULL,NULL,NULL,0),(6,'Special','11','15','1',1.0000,'4.34','130','0.5','0.8','6',1,NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `m002` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m003`
--

DROP TABLE IF EXISTS `m003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m003` (
  `user_id` int(11) NOT NULL,
  `pin` int(11) DEFAULT NULL,
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='pin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m003`
--

LOCK TABLES `m003` WRITE;
/*!40000 ALTER TABLE `m003` DISABLE KEYS */;
INSERT INTO `m003` VALUES (1,8,NULL,NULL,NULL,'42.114.47.218','2016-11-28 13:47:44','1',0),(2,14,NULL,NULL,NULL,'59.153.235.214','2016-09-18 14:21:50','2',0),(46,0,'127.0.0.1','2016-09-14 21:54:18','2','59.153.240.4','2016-09-23 06:30:34','46',0),(63,2,'59.153.235.64','2016-09-22 11:31:56','46','123.16.24.86','2016-09-22 12:47:14','63',0);
/*!40000 ALTER TABLE `m003` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m004`
--

DROP TABLE IF EXISTS `m004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m004` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `balance_pin` int(11) DEFAULT '0',
  `user_id_from` int(11) DEFAULT NULL,
  `pin_tranfer` int(11) NOT NULL,
  `description` longtext,
  `type` varchar(45) NOT NULL,
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_update_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='history tranfer pin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m004`
--

LOCK TABLES `m004` WRITE;
/*!40000 ALTER TABLE `m004` DISABLE KEYS */;
INSERT INTO `m004` VALUES (1,2,14,NULL,1,NULL,'4','127.0.0.1','2016-09-14 19:10:46',NULL,NULL,NULL,NULL,0),(2,2,14,NULL,2,NULL,'4','127.0.0.1','2016-09-14 19:23:37',NULL,NULL,NULL,NULL,0),(3,46,1,2,1,NULL,'2','127.0.0.1','2016-09-14 21:54:18',NULL,NULL,NULL,NULL,0),(4,2,14,46,1,NULL,'1','127.0.0.1','2016-09-14 21:54:18',NULL,NULL,NULL,NULL,0),(5,1,5,NULL,1,NULL,'4','116.107.221.33','2016-09-18 04:04:21',NULL,NULL,NULL,NULL,0),(6,1,5,NULL,1,NULL,'4','116.107.221.33','2016-09-18 04:25:45',NULL,NULL,NULL,NULL,0),(7,1,5,NULL,1,NULL,'4','116.107.221.33','2016-09-18 04:25:50',NULL,NULL,NULL,NULL,0),(8,46,1,2,3,NULL,'2','59.153.235.214','2016-09-18 14:21:50',NULL,NULL,NULL,NULL,0),(9,2,14,46,3,NULL,'1','59.153.235.214','2016-09-18 14:21:50',NULL,NULL,NULL,NULL,0),(10,46,1,NULL,1,NULL,'4','59.153.235.214','2016-09-18 14:30:04',NULL,NULL,NULL,NULL,0),(11,46,1,1,1,NULL,'2','118.71.104.188','2016-09-19 01:26:40',NULL,NULL,NULL,NULL,0),(12,1,5,46,1,NULL,'1','118.71.104.188','2016-09-19 01:26:40',NULL,NULL,NULL,NULL,0),(13,63,3,46,3,NULL,'2','59.153.235.64','2016-09-22 11:31:56',NULL,NULL,NULL,NULL,0),(14,46,1,63,3,NULL,'1','59.153.235.64','2016-09-22 11:31:56',NULL,NULL,NULL,NULL,0),(15,63,2,NULL,1,NULL,'4','123.16.24.86','2016-09-22 12:47:14',NULL,NULL,NULL,NULL,0),(16,46,0,NULL,1,NULL,'3','59.153.240.4','2016-09-23 06:30:34',NULL,NULL,NULL,NULL,0),(17,1,4,NULL,1,NULL,'4','192.168.1.24','2016-11-25 12:30:41',NULL,NULL,NULL,NULL,0),(18,1,3,NULL,1,NULL,'4','192.168.1.24','2016-11-25 13:43:48',NULL,NULL,NULL,NULL,0),(19,1,2,NULL,1,NULL,'4','192.168.1.24','2016-11-25 13:47:39',NULL,NULL,NULL,NULL,0),(20,1,1,NULL,1,NULL,'3','192.168.1.24','2016-11-26 04:46:19',NULL,NULL,NULL,NULL,0),(21,1,0,NULL,1,NULL,'3','192.168.1.24','2016-11-26 04:53:02',NULL,NULL,NULL,NULL,0),(22,1,11,NULL,1,NULL,'3','192.168.1.24','2016-11-26 04:54:07',NULL,NULL,NULL,NULL,0),(23,1,10,NULL,1,NULL,'4','127.0.0.1','2016-11-28 19:53:54',NULL,NULL,NULL,NULL,0),(24,1,8,NULL,2,NULL,'4','42.114.47.218','2016-11-28 13:47:44',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `m004` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m005`
--

DROP TABLE IF EXISTS `m005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m005` (
  `tree_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `lft` int(11) NOT NULL,
  `rht` int(11) NOT NULL,
  `lvl` mediumint(9) NOT NULL,
  PRIMARY KEY (`tree_id`),
  UNIQUE KEY `name_UNIQUE` (`user_id`),
  KEY `trees_nav_idx` (`lft`,`rht`,`lvl`),
  KEY `trees_name_idx` (`user_id`,`lvl`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m005`
--

LOCK TABLES `m005` WRITE;
/*!40000 ALTER TABLE `m005` DISABLE KEYS */;
INSERT INTO `m005` VALUES (1,0,'Root',NULL,1,42,0),(2,1,'admin','',2,41,1),(3,2,'MarkLarry','',3,34,2),(4,46,'Larybc','',4,21,3),(6,57,'Martin','',5,6,4),(7,58,'Alain','',22,23,3),(8,59,'Eaglebc','',24,25,3),(9,60,'Tiger','',26,27,3),(10,61,'Mavella','',28,29,3),(11,62,'Snehal','',30,31,3),(12,63,'dnloc83','',7,12,4),(13,64,'Hungbc','',8,9,5),(14,65,'Blienbitcoin','',13,14,4),(15,66,'Rosemary','',15,16,4),(16,67,'Chalie','',17,18,4),(17,68,'Bigson','',19,20,4),(18,69,'Hk01','',10,11,5),(19,70,'Topbc','',32,33,3),(20,71,'admin001','',35,40,2),(21,72,'admin002','',36,37,3),(22,73,'admin02','',38,39,3);
/*!40000 ALTER TABLE `m005` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m006`
--

DROP TABLE IF EXISTS `m006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m006` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_from_id` int(11) DEFAULT NULL,
  `user_to_id` int(11) DEFAULT NULL,
  `msg_content` longtext,
  `user_read` json DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='messenger';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m006`
--

LOCK TABLES `m006` WRITE;
/*!40000 ALTER TABLE `m006` DISABLE KEYS */;
INSERT INTO `m006` VALUES (1,1,-1,'tset1','[\"2\", \"3\", \"1\", \"63\"]',3,'127.0.0.1','2016-09-17 19:38:59','1',NULL,NULL,NULL,0),(2,1,-1,'fhjgjhk','[\"1\", \"63\"]',3,'127.0.0.1','2016-09-18 01:16:37','1',NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `m006` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m008`
--

DROP TABLE IF EXISTS `m008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m008` (
  `news_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) DEFAULT NULL,
  `image` varchar(1000) DEFAULT NULL,
  `description` text,
  `del_flag` int(1) DEFAULT NULL,
  `ip_create` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(100) DEFAULT NULL,
  `ip_update` varchar(100) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m008`
--

LOCK TABLES `m008` WRITE;
/*!40000 ALTER TABLE `m008` DISABLE KEYS */;
/*!40000 ALTER TABLE `m008` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(2) NOT NULL,
  `role_name` varchar(45) DEFAULT NULL,
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_update_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='roles';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'guest',NULL,NULL,NULL,NULL,NULL,NULL,0),(2,'member',NULL,NULL,NULL,NULL,NULL,NULL,0),(3,'admin',NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s001`
--

DROP TABLE IF EXISTS `s001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s001` (
  `lang_id` int(11) NOT NULL,
  `lang_code` varchar(45) NOT NULL,
  `lang_name` varchar(45) NOT NULL,
  `ip_create` datetime DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`lang_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='language';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s001`
--

LOCK TABLES `s001` WRITE;
/*!40000 ALTER TABLE `s001` DISABLE KEYS */;
INSERT INTO `s001` VALUES (1,'vn','Viet Nam',NULL,NULL,NULL,NULL,NULL,NULL,0),(2,'en','English',NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `s001` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s002`
--

DROP TABLE IF EXISTS `s002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s002` (
  `sys_name` varchar(45) NOT NULL,
  `sys_value` varchar(45) DEFAULT NULL,
  `ip_create` datetime DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`sys_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s002`
--

LOCK TABLES `s002` WRITE;
/*!40000 ALTER TABLE `s002` DISABLE KEYS */;
INSERT INTO `s002` VALUES ('max_bit_month','30',NULL,NULL,NULL,NULL,NULL,NULL,0),('mng1','0.6',NULL,NULL,NULL,NULL,NULL,NULL,0),('mng2','0.7',NULL,NULL,NULL,NULL,NULL,NULL,0),('mng3','0.8',NULL,NULL,NULL,NULL,NULL,NULL,0),('mng4','1',NULL,NULL,NULL,NULL,NULL,NULL,0),('mng5','1.3',NULL,NULL,NULL,NULL,NULL,NULL,0),('pin_cost_wd','1',NULL,NULL,NULL,NULL,NULL,NULL,0),('request_pin_cost','0.011',NULL,NULL,NULL,NULL,NULL,NULL,0),('sponsor_interest_rate','10',NULL,NULL,NULL,NULL,NULL,NULL,0),('wallet','1QDMZmanpD6PTtrDQf1UTsu1uuRM3Ntb6j',NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `s002` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s003`
--

DROP TABLE IF EXISTS `s003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s003` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) DEFAULT NULL,
  `img_path` varchar(500) DEFAULT NULL,
  `type` varchar(500) DEFAULT NULL,
  `link` longtext,
  `content` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='home settings';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s003`
--

LOCK TABLES `s003` WRITE;
/*!40000 ALTER TABLE `s003` DISABLE KEYS */;
/*!40000 ALTER TABLE `s003` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `id` char(32) NOT NULL,
  `modified` int(11) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `trees`
--

DROP TABLE IF EXISTS `trees`;
/*!50001 DROP VIEW IF EXISTS `trees`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `trees` AS SELECT 
 1 AS `tree_id`,
 1 AS `user_id`,
 1 AS `user_name`,
 1 AS `description`,
 1 AS `lvl`,
 1 AS `cnt_children`,
 1 AS `is_branch`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `w001`
--

DROP TABLE IF EXISTS `w001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `w001` (
  `user_id` int(11) NOT NULL,
  `balance_in` double(15,8) DEFAULT '0.00000000',
  `r_wallet` double(15,8) DEFAULT '0.00000000',
  `sponsor_bonus` double(15,8) DEFAULT '0.00000000',
  `manager_bounus` double(15,8) DEFAULT '0.00000000',
  `withdrawable1` double(15,8) DEFAULT '0.00000000',
  `withdrawable2` double(15,8) DEFAULT '0.00000000',
  `ip_create` varchar(45) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `user_created_id` varchar(200) DEFAULT NULL,
  `ip_update` varchar(45) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `user_updated_id` varchar(200) DEFAULT NULL,
  `del_flag` int(1) DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='wallet , profit, bonus';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `w001`
--

LOCK TABLES `w001` WRITE;
/*!40000 ALTER TABLE `w001` DISABLE KEYS */;
INSERT INTO `w001` VALUES (1,0.80500000,1.97654000,0.00000000,0.00000000,0.74500000,1.13660000,NULL,NULL,NULL,'42.114.47.218','2016-12-23 00:00:02',NULL,0),(2,2.10000000,0.22494000,0.01000000,NULL,1.45000000,2.32000000,NULL,NULL,NULL,'127.0.0.1','2016-10-17 00:00:02',NULL,0),(46,0.00000000,0.13000000,0.00000000,0.00000000,0.05000000,0.08000000,NULL,NULL,NULL,'59.153.235.214','2016-10-17 00:00:02',NULL,0),(57,0.00000000,0.13000000,0.00000000,0.00000000,0.05000000,0.08000000,NULL,NULL,NULL,NULL,NULL,NULL,0),(60,0.00000000,0.00000000,0.00000000,0.00000000,0.00000000,0.00000000,NULL,NULL,NULL,NULL,NULL,NULL,0),(63,0.00000000,0.00000000,0.00000000,0.00000000,0.05000000,0.08000000,NULL,NULL,NULL,'123.16.24.86','2016-10-21 00:00:02',NULL,0),(71,0.00000000,0.00000000,0.00000000,0.00000000,0.00000000,0.00000000,NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `w001` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'finance'
--
/*!50003 DROP PROCEDURE IF EXISTS `add_all_role` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_all_role`()
BEGIN
	INSERT INTO acl_to_role (role_id, acl_id, active)
	SELECT role.role_id, acl.acl_id, 1
	FROM role, acl;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_get_total_gh_bit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `admin_get_total_gh_bit`()
BEGIN
	SET @w_time = now();
	SET @three_day_ago_date = date_add(CURDATE(), INTERVAL - 2 DAY);
    
	SELECT sum(amount) AS all_bit
	FROM d002 
	WHERE d002.create_date < @three_day_ago_date 
	AND d002.`status` = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_get_wallet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `admin_get_wallet`()
BEGIN
SELECT * FROM s002 WHERE sys_name = 'wallet';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_list_gh` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `admin_list_gh`(
	IN p_date_from DATE
)
BEGIN

	DECLARE total_row INT DEFAULT 0;
    DECLARE total_bit decimal(15,8) DEFAULT 0;
    
	SET @w_time = now();
	SET @three_day_ago_date = date_add(CURDATE(), INTERVAL - 2 DAY);
   
	SELECT  count(*), sum(amount) INTO total_row, total_bit
	FROM d002 
	WHERE d002.create_date < @three_day_ago_date 
    AND d002.create_date > p_date_from
	AND d002.`status` = 1;

	SELECT 
		d002.id,
		d002.user_id,
		m001.user_name,
		d002.amount,
		d002.create_date,
		DATEDIFF(@w_time, d002.create_date) AS day_ago,
		total_bit AS total_bit,
		total_row AS total
	FROM
		d002
			LEFT JOIN
		m001 ON d002.user_id = m001.user_id
	WHERE
		d002.create_date < @three_day_ago_date
	AND d002.create_date > p_date_from
	AND d002.`status` = 1
	LIMIT 0 , 20

	;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_save_pk` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_save_pk`(
	IN p_id   INT,
    IN p_rate  DECIMAL(10,4),
    IN p_pin_cost INT,
	-- IN p_pin_cost_gh INT,
    IN p_user_id INT,
    IN p_ip	VARCHAR(50)
)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT @p1, @p2;
		SELECT * FROM tbl_respon;
		ROLLBACK;
          
    END;
    
    START TRANSACTION;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
    
	SET @w_time = now();
	SET @interest_rate = CEIL((p_rate*30 + 100)*100/30) /100;
    SET @allow_rate = p_rate*30/100 + 0.5;
    UPDATE m002
    SET rate = p_rate
    ,	pin_cost = p_pin_cost
 --   ,	pin_cost_gh = p_pin_cost_gh
    ,	interest_rate = @interest_rate
    , 	max_rate = p_rate*30 + 100
    ,   allow_bit_rate = @allow_rate
    WHERE id = p_id;
	
    
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
		ROLLBACK;
	ELSE 
		COMMIT;
		SELECT '1' AS success;
	END IF;
	DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_save_rate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_save_rate`(
	IN p_name   VARCHAR(50),
    IN p_value  VARCHAR(50),
    IN p_user_id INT,
    IN p_ip	VARCHAR(50)
)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT @p1, @p2;
		SELECT * FROM tbl_respon;
		ROLLBACK;
          
    END;
    
    START TRANSACTION;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
    
	SET @w_time = now();
	
    UPDATE s002
    SET sys_value = p_value
    WHERE sys_name = p_name;
	
    
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
		ROLLBACK;
	ELSE 
		COMMIT;
		SELECT '1' AS success;
	END IF;
	DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_save_setting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `admin_save_setting`(
	IN p_id INT ,
    IN p_title varchar(500),
    IN P_img_path varchar(500),
    IN p_link longtext,
    IN p_content longtext
    
)
BEGIN
	
    UPDATE s003
    SET title = p_title,
    img_path = P_img_path,
    link = p_link,
    content = p_content
    WHERE id = p_id;
    
    SELECT 1 AS 'success';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_save_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_save_status`(
	IN p_user_id   INT,
    IN p_status  VARCHAR(50),
    IN p_update_user_id INT,
    IN p_ip	VARCHAR(50)
)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT @p1, @p2;
		SELECT * FROM tbl_respon;
		ROLLBACK;
          
    END;
    
    START TRANSACTION;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
    
	SET @w_time = now();
	
    UPDATE m001
    SET status = p_status
    WHERE user_id = p_user_id;
	
    
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
		ROLLBACK;
	ELSE 
		COMMIT;
		SELECT '1' AS success;
	END IF;
	DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_settings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `admin_settings`()
BEGIN
	SELECT 
		`sys_name`,
        `sys_value`
    FROM s002;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `auth_login_check` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `auth_login_check`(
	IN  p_user_name VARCHAR(200)
,	IN  p_pwd VARCHAR(200)
,	IN	p_static_salt VARCHAR(200)
,	IN	p_ip	VARCHAR(50)
)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT 1, @p1, @p2;
        SELECT * FROM tbl_respon;
          
    END;
    CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		id INT(11) NULL default 0
	,	code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
    
	SET p_pwd = md5(sha1(CONCAT(p_static_salt,p_pwd)));
    
    IF EXISTS (
					SELECT 
						1
					FROM
						m001
					WHERE
						m001.del_flag = 0 AND m001.status = '1'
							AND m001.password = p_pwd
							AND (m001.user_name = p_user_name OR m001.email = p_user_name)
					LIMIT 1
    )  THEN 
    
			SET @user_id = (SELECT 
				m001.user_id
            FROM m001
            WHERE
				m001.del_flag = 0 
                AND m001.status = '1'
				AND m001.password = p_pwd
				AND (m001.user_name = p_user_name OR m001.email = p_user_name)
			LIMIT 1);
            -- update 
			set @w_time = now();
            update m001
			set ip_update = p_ip 
            , update_date = @w_time
            , reset_pass_code = null
			where m001.user_id = @user_id;
            
            -- get data
			SELECT m001.*
            ,   role.role_name
			,	m003.pin
            ,	m005.tree_id
            ,   btc001.btc_address
            ,   btc001.btc_label
            FROM m001
           
            LEFT JOIN m003 ON m001.user_id = m003.user_id
            LEFT JOIN role ON m001.role_id = role.role_id
            LEFT JOIN m005 ON m001.user_id = m005.user_id
            LEFT JOIN btc001 ON m001.user_id = btc001.user_id
            where m001.user_id = @user_id
			LIMIT 1
            ;
            
            
			
		ELSE 
			SELECT 'fail' AS fail;
	END IF;
	
    DROP TEMPORARY TABLE IF EXISTS tbl_respon;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `change_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `change_password`(
	IN p_pwd varchar(200),
    IN p_reset_code varchar(200),
    IN p_email varchar(200),
    IN p_ip varchar(200)
)
BEGIN
	set @w_time = now();
    SET @user_id = (SELECT user_id FROM m001 where email = p_email AND reset_pass_code IS NOT NULL AND reset_pass_code = p_reset_code LIMIT 1);
	IF @user_id  IS NOT NULL
    THEN
		
		update m001 
        SET `password` = p_pwd
        , reset_pass_code = NULL
        , update_date = @w_time
        , ip_update = p_ip
        WHERE user_id = @user_id
        ;
        
		SELECT 1 AS status;
    ELSE
		SELECT 0 AS status;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_exists_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_exists_email`(
	IN p_email varchar(200),
    IN p_reset_code varchar(200),
    IN p_ip varchar(200)
)
BEGIN
	set @w_time = now();
	IF EXISTS(SELECT 1 FROM m001 where email = p_email)
    THEN
		update m001 
        SET reset_pass_code = p_reset_code
        , update_date = @w_time
        , ip_update = p_ip
        WHERE email = p_email;
		SELECT 1 AS status;
    ELSE
		SELECT 0 AS status;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `dashboard_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `dashboard_info`(
	IN p_user_id INT 
)
BEGIN
	DROP TEMPORARY TABLE IF EXISTS tbl_top_tree;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_top_tree
		(	
			tree_id INT,
			user_id INT,
            user_name varchar(200),
			despcription longtext,
            lvl int,
			cnt_children int,
			is_branch int,
            rank_name varchar(50),
            status_name varchar(50),
            create_date DATETIME
			
		);

	INSERT INTO tbl_top_tree
	SELECT 
        m005.tree_id AS tree_id,
        m005.user_id AS user_id,
        CONCAT(REPEAT('', (m005.lvl - 0)),
                m005.user_name) AS user_name,
        m005.description AS description,
        m005.lvl AS lvl,
        FORMAT((((m005.rht - m005.lft) - 1) / 2),
            0) AS cnt_children,
        (CASE
            WHEN ((m005.rht - m005.lft) > 1) THEN 1
            ELSE 0
        END) AS is_branch,
        lib001.value AS rank_name,
		status_acc.value AS status_name,
        m001.create_date
    FROM
        m005
        LEFT JOIN m001 ON m005.user_id = m001.user_id
		LEFT JOIN
		lib001 ON lib001.code = 'rank'
			AND m001.rank = lib001.value_id
			LEFT JOIN
		lib001 AS status_acc ON status_acc.code = 'status_acc'
			AND m001.status = status_acc.value_id
    WHERE
        (m005.lft >= 1)
        AND m001.del_flag = 0
    ORDER BY cnt_children DESC, m005.lft ASC;

	-- get coin
	SELECT 
		*
	FROM
		w001
	WHERE
		w001.user_id = p_user_id
			AND del_flag = 0;
	-- get pin
	SELECT 
		*
	FROM
		m003
	WHERE
		m003.user_id = p_user_id
			AND del_flag = 0;
	-- get child
	SELECT 
		*
	FROM
		tbl_top_tree
	WHERE
		tbl_top_tree.user_id = p_user_id
	LIMIT 1;
	   
	-- top 15 
	SELECT 
		*
	FROM
		tbl_top_tree
	ORDER BY cnt_children DESC
	LIMIT 0 , 15;
		
	-- package info
	SELECT 
		sum(d001.amount * m002.interest_rate)/100 AS rate_day
	FROM
		d001
			LEFT JOIN
		m002 ON d001.package_id = m002.id
	WHERE
		d001.user_id = p_user_id
			AND d001.status = 1
	;
    
    DROP TEMPORARY TABLE IF EXISTS tbl_top_tree;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `dashboard_top_tree` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `dashboard_top_tree`()
BEGIN
SELECT 
        m005.tree_id AS tree_id,
        m005.user_id AS user_id,
        CONCAT(REPEAT('', (m005.lvl - 0)),
                m005.user_name) AS user_name,
        m005.description AS description,
        m005.lvl AS lvl,
        FORMAT((((m005.rht - m005.lft) - 1) / 2),
            0) AS cnt_children,
        (CASE
            WHEN ((m005.rht - m005.lft) > 1) THEN 1
            ELSE 0
        END) AS is_branch,
        lib001.value AS rank_name,
		status_acc.value AS status_name,
        m001.create_date
    FROM
        m005
        LEFT JOIN m001 ON m005.user_id = m001.user_id
		LEFT JOIN
		lib001 ON lib001.code = 'rank'
			AND m001.rank = lib001.value_id
			LEFT JOIN
		lib001 AS status_acc ON status_acc.code = 'status_acc'
			AND m001.status = status_acc.value_id
    WHERE
        (m005.lft >= 1)
        AND m001.del_flag = 0
    ORDER BY cnt_children DESC, m005.lft ASC
    LIMIT 0, 15;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllF1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllF1`(
	IN  p_user_id INT
)
BEGIN
	SELECT 
		*
	FROM m001
	WHERE del_flag = '0' 
		AND `status` = 1
		AND parent_user_id = p_user_id
;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAmount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAmount`(
	IN  p_user_id INT
)
proctu: BEGIN
	-- Declare variables
	DECLARE tree_no_id CONDITION FOR SQLSTATE '45000';
	DECLARE tree_id_not_found  CONDITION FOR SQLSTATE '45000';
    DECLARE t_node_found INT DEFAULT NULL;
	DECLARE t_node_lft INT DEFAULT NULL;
	DECLARE t_node_rht INT DEFAULT NULL;
	DECLARE t_node_lvl MEDIUMINT DEFAULT NULL;
    
	SET @tree_id = (SELECT tree_id from m005 WHERE user_id = p_user_id);

	IF ( @tree_id IS NULL) THEN
		SIGNAL tree_no_id
			SET MESSAGE_TEXT = 'tree_id not exists';
            LEAVE proctu;
	ELSE 
		CALL get_branch(@tree_id, NULL, NULL);
        
		-- SELECT user_id FROM tbl_result;
        SELECT SUM(d001.amount) AS amount_total
        FROM d001 
        INNER JOIN tbl_result ON d001.user_id = tbl_result.user_id AND tbl_result.user_id <> p_user_id
		WHERE d001.type = 1
		AND d001.status = 1;
	END IF;
    
    
    DROP TEMPORARY TABLE IF EXISTS tbl_result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAmountF1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAmountF1`(
	IN  p_user_id INT,
    IN  duration datetime
)
BEGIN
      
	SELECT SUM(d001.amount) AS amount_total
	FROM d001 
	INNER JOIN m001 ON d001.user_id = m001.user_id AND m001.parent_user_id = p_user_id AND del_flag = '0'
	WHERE (1=1)
    AND d001.type = 1
	-- AND d001.status = 1
    AND d001.create_date >= duration
    ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAmountLimit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAmountLimit`(
	IN  p_user_id INT,
    IN  p_lvl INT
)
proctu: BEGIN
	-- Declare variables
	DECLARE tree_no_id CONDITION FOR SQLSTATE '45000';
	DECLARE tree_id_not_found  CONDITION FOR SQLSTATE '45000';
    DECLARE t_node_found INT DEFAULT NULL;
	DECLARE t_node_lft INT DEFAULT NULL;
	DECLARE t_node_rht INT DEFAULT NULL;
	DECLARE t_node_lvl MEDIUMINT DEFAULT NULL;
    
	SET @tree_id = (SELECT tree_id from m005 WHERE user_id = p_user_id);

	IF ( @tree_id IS NULL) THEN
		SIGNAL tree_no_id
			SET MESSAGE_TEXT = 'tree_id not exists';
            LEAVE proctu;
	ELSE 
		CALL get_branch(@tree_id, p_lvl, NULL);
        
		-- SELECT user_id FROM tbl_result;
        SELECT SUM(d001.amount) AS amount_total
        FROM d001 
        INNER JOIN tbl_result ON d001.user_id = tbl_result.user_id AND tbl_result.user_id <> p_user_id
		WHERE d001.type = 1
		AND d001.status = 1;
	END IF;
    
    
    DROP TEMPORARY TABLE IF EXISTS tbl_result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getChildrent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getChildrent`(
	IN  p_user_id INT
)
BEGIN
	DECLARE e_no_relation CONDITION FOR SQLSTATE '45000';
	SET @tree_id = (SELECT tree_id from m005 WHERE user_id = p_user_id);
   
	IF ( @tree_id IS NOT NULL ) THEN
             CALL tree_get_branch( @tree_id , NULL, NULL);
	ELSE
		SIGNAL e_no_relation
			SET MESSAGE_TEXT = 'Not user in tree';
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gethelp_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `gethelp_info`(
	IN p_user_id INT
)
BEGIN
	SELECT 
		d002.user_id,
		d002.amount,
		d002.status,
        lib001.value AS status_name,
		d002.create_date,
		d002.update_date
	FROM d002
    LEFT JOIN
		lib001 ON lib001.code = 'status_dnt_gh'
			AND d002.status = lib001.value_id
    WHERE d002.del_flag = 0
    AND d002.user_id = p_user_id
    AND EXISTS( SELECT 1 FROM m001 WHERE m001.user_id = p_user_id AND m001.del_flag = 0 AND m001.status = 1)
    ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gettotalF1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `gettotalF1`(
	IN  p_user_id INT
)
BEGIN
	SELECT 
		COUNT(*) AS total
	FROM m001
	WHERE del_flag = '0' 
		AND `status` = 1
		AND parent_user_id = p_user_id
;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getu` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getu`(
	IN  p_user_id INT
)
proctu: BEGIN
	-- Declare variables
	DECLARE tree_no_id CONDITION FOR SQLSTATE '45000';
	DECLARE tree_id_not_found  CONDITION FOR SQLSTATE '45000';
    DECLARE t_node_found INT DEFAULT NULL;
	DECLARE t_node_lft INT DEFAULT NULL;
	DECLARE t_node_rht INT DEFAULT NULL;
	DECLARE t_node_lvl MEDIUMINT DEFAULT NULL;
    
	SET @tree_id = (SELECT tree_id from m005 WHERE user_id = p_user_id);

	IF ( @tree_id IS NULL) THEN
		SIGNAL tree_no_id
			SET MESSAGE_TEXT = 'tree_id not exists';
            LEAVE proctu;
	END IF;
    SELECT tree_id, lft , rht ,lvl INTO t_node_found, t_node_lft, t_node_rht, t_node_lvl
	  FROM m005
	 WHERE tree_id = @tree_id;
     
     
    SET @tree_id_left  =( SELECT tree_id
	  FROM m005
	 WHERE lft >= t_node_lft
	   AND lft < t_node_rht
	   AND lvl = t_node_lvl + 1
	 ORDER BY lft
     LIMIT 0,1
     );
     
     SET @tree_id_right  =( SELECT tree_id
	  FROM m005
	 WHERE lft >= t_node_lft
	   AND lft < t_node_rht
	   AND lvl = t_node_lvl + 1
	 ORDER BY lft
     LIMIT 1,1
     );
     
    -- SELECT @tree_id_left, @tree_id_right,t_node_found, t_node_lft, t_node_rht, t_node_lvl;
     IF ( @tree_id_left IS NULL) THEN
		SELECT "Not left"; 
	 ELSE
		-- CALL tree_get_branch( @tree_id_left , NULL, NULL);
        SELECT @tree_id_left AS Tree_left;
	 END IF;
     
     IF ( @tree_id_right IS NULL) THEN
		SELECT "Not right"; 
	 ELSE
		-- CALL tree_get_branch( @tree_id_right , NULL, NULL);
        SELECT @tree_id_right AS Tree_right;
	 END IF;
     
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_acls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_acls`()
BEGIN
	SELECT 
		role.role_name,
		acl.module,
		acl.controller,
		acl.action,
		atr.active
	FROM
		acl_to_role AS atr
			LEFT JOIN
		role ON atr.role_id = role.role_id
			LEFT JOIN
		acl ON atr.acl_id = acl.acl_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_add_tree_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_add_tree_info`(
	IN p_user_id INT
)
BEGIN
	SELECT 
		m001.user_id
	,	m001.user_name
	FROM
		m001
	WHERE
		del_flag = '0' 
		AND parent_user_id = p_user_id
		AND NOT EXISTS(SELECT 1 FROM m005 WHERE m005.user_id = m001.user_id)
	;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_users`(
	IN p_user_id INT
)
BEGIN
	SELECT 
		user_id, user_name
	FROM
		m001
	WHERE
		del_flag = 0 AND status = 1
        AND user_id <> p_user_id
	;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_branch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_branch`(
     IN p_id INT
    ,IN p_depth TINYINT
    ,IN p_indent VARCHAR(20)
    )
proc: BEGIN
		
        -- Declare variables
        DECLARE e_no_id CONDITION FOR SQLSTATE '45000';
        DECLARE e_id_not_found  CONDITION FOR SQLSTATE '45000';
        DECLARE v_node_found INT DEFAULT NULL;
        DECLARE v_node_lft INT DEFAULT NULL;
        DECLARE v_node_rht INT DEFAULT NULL;
        DECLARE v_node_lvl MEDIUMINT DEFAULT NULL;
        DECLARE v_indent VARCHAR(20) DEFAULT NULL;
        DECLARE v_depth TINYINT DEFAULT 127;
        
        DROP TEMPORARY TABLE IF EXISTS tbl_result;
        CREATE TEMPORARY TABLE IF NOT EXISTS tbl_result
		(	
			tree_id INT,
            parent_tree_id INT,
			user_id INT,
			user_name varchar(200),
			despcription longtext,
			lft int,
            rht int,
            lvl int,
			cnt_children int,
			is_branch int
			
		);

        -- Validate the tree_id
        IF ( p_id IS NULL) THEN
            SIGNAL e_no_id
                SET MESSAGE_TEXT = 'The id cannot be empty.';
            LEAVE proc;
        END IF;
        SELECT tree_id, lft , rht ,lvl INTO v_node_found, v_node_lft, v_node_rht, v_node_lvl
          FROM m005
         WHERE tree_id = p_id;

        IF ( v_node_found IS NULL) THEN
            SIGNAL e_id_not_found
                SET MESSAGE_TEXT = 'The tree_id does not exists.';
            LEAVE proc;
        END IF;

        -- Use default values if NULL is given as parameter
        SET v_indent := COALESCE( p_indent, '');
        SET v_depth := COALESCE( p_depth, v_depth);

        -- select the branch
        INSERT INTO tbl_result
        SELECT m005.tree_id
			 , parent.tree_id
             , m005.user_id
             , CONCAT(REPEAT( v_indent, (m005.lvl - v_node_lvl) ), m005.user_name) AS user_name
             , m005.description
             , m005.lft
             , m005.rht
             , m005.lvl
             , FORMAT((((m005.rht - m005.lft) -1) / 2),0) AS cnt_children
            , CASE WHEN m005.rht - m005.lft > 1 THEN 1 ELSE 0 END AS is_branch
          FROM m005
          
		LEFT JOIN m005 AS parent ON 
m005.lft > parent.lft 
AND m005.lft < parent.rht
AND m005.lvl = (parent.lvl + 1)

         WHERE m005.lft >= v_node_lft
           AND m005.lft < v_node_rht
           AND m005.lvl <= v_node_lvl + v_depth
         ORDER BY m005.lft;
         -- select * FROM tbl_result;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_help_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_help_info`(
	IN p_user_id INT 
)
BEGIN
	-- get coin
    SELECT 
		COALESCE(withdrawable2, 0) + COALESCE(sponsor_bonus, 0) +COALESCE(manager_bounus, 0) AS withdrawable
    FROM w001 
    WHERE w001.user_id = p_user_id 
    AND del_flag = 0;
    -- get pin
   -- SELECT * FROM m003 WHERE m003.user_id = p_user_id AND del_flag = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_roles` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_roles`()
BEGIN
	SELECT role.role_id,
    role.role_name
    FROM role 
    WHERE del_flag = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_save_gh` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_save_gh`(
    IN p_user_id INT,
    IN p_ip	VARCHAR(50)
)
BEGIN
  
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT @p1, @p2;
        SELECT * FROM tbl_respon;
        ROLLBACK;  
    END;
    
    START TRANSACTION;
    DROP TEMPORARY TABLE IF EXISTS tbl_respon;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
    
		SET @w_time = now();
		SET @withdrawable =  (SELECT COALESCE(withdrawable2, 0) + COALESCE(sponsor_bonus, 0) +COALESCE(manager_bounus, 0) 
								FROM w001 
                                WHERE w001.user_id = p_user_id AND del_flag = '0' LIMIT 1);
		SET @pin_cost = (SELECT cast(sys_value AS SIGNED ) FROM s002 WHERE s002.sys_name = 'pin_cost_wd' LIMIT 1);
        
        IF NOT EXISTS (SELECT 1 FROM m003 
			WHERE m003.user_id = p_user_id
				AND m003.del_flag = '0'
				AND m003.pin >=  @pin_cost
		) 
		THEN 
			INSERT INTO tbl_respon
			SELECT '1', 'Not enough pin!';

		END IF;
        IF @withdrawable > 0 AND NOT EXISTS (SELECT 1 FROM tbl_respon)
        THEN
			INSERT INTO d002 (
				user_id,
				amount,
				`status`,
				ip_create,
				create_date
			)
			VALUES ( p_user_id, @withdrawable, 1,p_ip, @w_time);  -- adddate(@w_time, INTERVAL 3 DAY)
			
			-- update withdraw
			UPDATE w001
			SET 
				sponsor_bonus = 0,
				manager_bounus = 0,
                r_wallet = r_wallet - withdrawable2,
                withdrawable2 = 0
			WHERE user_id = p_user_id
			AND del_flag = '0'; 
            
            
			-- update pin/token
			UPDATE m003
			set ip_update = p_ip 
			, update_date = @w_time
			, pin = @balance_pin := pin - @pin_cost
			, user_updated_id = p_user_id
			where m003.user_id = p_user_id;
			
			-- history pin
			INSERT INTO m004 (
			user_id,
			balance_pin,
			pin_tranfer,
			type,
			ip_create,
			create_date
			)
			VALUES ( p_user_id, @balance_pin, @pin_cost, 3, p_ip, @w_time);
        
        END IF;
     
        
 
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
        ROLLBACK;
	ELSE 
		COMMIT;
		SELECT '1' AS success;
	END IF;
    DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `home_default` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `home_default`()
BEGIN
	SELECT * FROM s003;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `home_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `home_info`()
BEGIN

	SELECT 
		d001.id,
		d001.user_id,
		m001.user_name,
        m001.rank,
        m001.sex,
		d001.package_id,
		m002.package_name,
		d001.amount,
		d001.create_date,
		TIMESTAMPDIFF(MINUTE,d001.create_date,NOW()) AS minute_ago
	 FROM finance.d001
	 LEFT JOIN m001 ON d001.user_id = m001.user_id
	 LEFT JOIN m002 ON d001.package_id = m002.id
	 LIMIT 0, 20;
     
	SELECT 
        m005.tree_id AS tree_id,
        m005.user_id AS user_id,
        CONCAT(REPEAT('', (m005.lvl - 0)),
                m005.user_name) AS user_name,
        m005.description AS description,
        m005.lvl AS lvl,
        FORMAT((((m005.rht - m005.lft) - 1) / 2),
            0) AS cnt_children,
        (CASE
            WHEN ((m005.rht - m005.lft) > 1) THEN 1
            ELSE 0
        END) AS is_branch,
        lib001.value AS rank_name,
		status_acc.value AS status_name,
        m001.create_date,
		m001.rank,
        m001.sex
    FROM
        m005
        LEFT JOIN m001 ON m005.user_id = m001.user_id
		LEFT JOIN
		lib001 ON lib001.code = 'rank'
			AND m001.rank = lib001.value_id
			LEFT JOIN
		lib001 AS status_acc ON status_acc.code = 'status_acc'
			AND m001.status = status_acc.value_id
    WHERE
        (m005.lft >= 1)
        AND m001.del_flag = 0
    ORDER BY cnt_children DESC, m005.lft ASC
    LIMIT 0, 15;
    
    -- 2
    SELECT cast(SUM(amount) AS decimal(15,2)) AS ph_total FROM d001;
      -- 3
    SELECT cast(SUM(amount) AS decimal(15,2)) AS gh_total FROM d002;
      -- 4
    SELECT 
		cast(SUM(amount * (max_rate - 100) / 100)AS decimal(15,2))AS profits_total
	FROM
		d001
			INNER JOIN
		m002 ON d001.package_id = m002.id
	;
	  -- 5
    SELECT COUNT(*) AS member_total FROM m001;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `job_get_send_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `job_get_send_daily`()
BEGIN
	SET @w_time = now();
	SET @three_day_ago_date = date_add(CURDATE(), INTERVAL - 2 DAY);


	SELECT 
		d002.user_id,
		btc001.btc_address,
		m001.user_name,
		SUM(d002.amount) AS amount_total

	FROM
		d002
			INNER JOIN
		m001 ON d002.user_id = m001.user_id
			INNER JOIN btc001 ON d002.user_id = btc001.user_id
	WHERE
		d002.create_date < @three_day_ago_date
			AND d002.`status` = 1
	GROUP BY d002.user_id, btc001.btc_address, m001.user_name
	ORDER BY d002.user_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `job_update_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `job_update_daily`(

)
BEGIN
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT @p1, @p2;
        SELECT * FROM tbl_respon;
        ROLLBACK;  
    END;
    
    START TRANSACTION;
	DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(800) NULL default ''
    );
    
    DROP TEMPORARY TABLE IF EXISTS tbl_tmp;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_tmp (
		id BIGINT NULL 
	,	user_id INT NULL 
    ,	amount decimal(15,8) NULL 
    ,	rate varchar(45) NULL
    ,	max_rate varchar(45) NULL
    ,	save_bit_rate varchar(45) NULL
    ,	create_date datetime NULL
	,	inerest decimal(15,8) NULL
    ,	max_inerest decimal(15,8) NULL
	,	withdrawable1 decimal(15,8) NULL
    ,	withdrawable2 decimal(15,8) NULL
    ,	count_day INT NULL
    );
    
	DROP TEMPORARY TABLE IF EXISTS tbl_interest;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_interest (
		user_id INT NULL 
	,	inerest decimal(15,8) NULL
	,	withdrawable1 decimal(15,8) NULL
    ,	withdrawable2 decimal(15,8) NULL
    );
    
    DROP TEMPORARY TABLE IF EXISTS tbl_interest_finish;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_interest_finish (
		user_id INT NULL 
	,	inerest decimal(15,8) NULL
    ,	withdrawable1 decimal(15,8) NULL
    ,	withdrawable2 decimal(15,8) NULL
    
    );
    
   
        SET SQL_SAFE_UPDATES = 0;
		SET @w_time = now();
		IF EXISTS(SELECT 1 FROM job_history WHERE type_job = 'job_update')
		THEN
			SET @last_run = (SELECT date_run FROM job_history WHERE type_job = 'job_update' );
		ELSE
			INSERT INTO job_history
            SELECT 'job_update', date_add(@w_time, INTERVAL - 1 DAY);
            
            SET @last_run = date_add(@w_time, INTERVAL - 1 DAY);
		END IF;
        
        
	IF(DATEDIFF(@w_time, @last_run) > 0)
	THEN
        INSERT INTO tbl_tmp
        SELECT
			d001.id,
			user_id,
			amount,
			rate,
			max_rate,
            save_bit_rate,
			d001.create_date,
			CAST(amount * max_rate/30 /100 AS DECIMAL(15,8)) AS inerest,
            CAST(amount * max_rate /100 AS DECIMAL(15,8)) AS max_inerest,
            CAST(amount * 100/30 * save_bit_rate /100 AS DECIMAL(15,8)) AS withdrawable1,
            CAST(amount * ( save_bit_rate /30  + rate/100)AS DECIMAL(15,8)) AS withdrawable2,
			DATEDIFF(@w_time, d001.create_date) AS count_day
		FROM d001
		WHERE d001.status= 1;
        
        INSERT INTO tbl_interest
        SELECT user_id
        , 	SUM(inerest)
        ,	SUM(withdrawable1)
        ,	SUM(withdrawable2)
        FROM tbl_tmp
        WHERE count_day < 30
        GROUP BY user_id;
        
		INSERT INTO tbl_interest_finish
        SELECT user_id
        ,	SUM(amount*max_rate/100) - SUM(inerest) * 29
        ,	SUM((amount*max_rate/100 - inerest * 29 - amount*rate/100)*save_bit_rate)  AS withdrawable1
        ,	SUM((amount*max_rate/100 - inerest * 29 - amount*rate)*save_bit_rate +  amount*rate/100) AS withdrawable2
        FROM tbl_tmp
        WHERE count_day = 30
        GROUP BY user_id; 
        
        -- update r_wallet
        UPDATE w001
        INNER JOIN tbl_interest ON w001.user_id = tbl_interest.user_id
        SET w001.r_wallet = COALESCE(w001.r_wallet, 0) + tbl_interest.inerest
        ,	w001.withdrawable1 = COALESCE(w001.withdrawable1, 0) + tbl_interest.withdrawable1
        ,	w001.withdrawable2 = COALESCE(w001.withdrawable2, 0) + tbl_interest.withdrawable2
        ,	update_date = @w_time
        WHERE w001.del_flag = '0'
		;
        
        -- update after 30 day
        UPDATE w001
        INNER JOIN tbl_interest_finish ON w001.user_id = tbl_interest_finish.user_id
        SET w001.r_wallet = COALESCE(w001.r_wallet, 0) + tbl_interest_finish.inerest
        ,	w001.withdrawable1 = COALESCE(w001.withdrawable1, 0) + tbl_interest_finish.withdrawable1
        ,	w001.withdrawable2 = COALESCE(w001.withdrawable2, 0) + tbl_interest_finish.withdrawable2
        ;
        -- update status d001
		UPDATE d001
        INNER JOIN tbl_tmp ON d001.user_id = tbl_tmp.id
        SET status = 2
		WHERE tbl_tmp.count_day >= 30;
        
     
    END IF;    
 
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
        ROLLBACK;
	ELSE 
		update job_history
        SET date_run = @w_time
        WHERE type_job = 'job_update';
        
		COMMIT;
		SELECT '1' AS success;
	END IF;
    
    DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    DROP TEMPORARY TABLE IF EXISTS tbl_tmp;
    DROP TEMPORARY TABLE IF EXISTS tbl_interest;
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `job_update_wallet_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `job_update_wallet_daily`(
	IN p_data JSON
)
proc: BEGIN

	DECLARE n INT DEFAULT 0;
   
	DROP TEMPORARY TABLE IF EXISTS tbl_user;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_user (
		user_id INT(11) NULL default 0
    );
    
    SET @length = JSON_LENGTH(p_data);
    
    IF @length IS NOT NULL
    THEN
	  SET n = 0;
      split: LOOP
		IF n < @length THEN
			INSERT INTO tbl_user
			SELECT  JSON_UNQUOTE(json_extract(p_data, concat('$[', n,']'))) ;
		ELSE
			LEAVE split;
		END IF;
        SET n = n + 1;
		
	  END LOOP split;
      
	END IF;
    
	SET SQL_SAFE_UPDATES=0;
	UPDATE d002 
	SET 
		d002.`status` = 2
	WHERE EXISTS(SELECT 1 FROM tbl_user WHERE tbl_user.user_id = d002.user_id)
	;
   SET SQL_SAFE_UPDATES=1;
   
SELECT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `listuser_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `listuser_info`(
	IN p_user_name varchar(50)
)
BEGIN
	SELECT * ,
    status_acc.value AS status_name
    FROM m001
    LEFT JOIN
		lib001 AS status_acc ON status_acc.code = 'status_acc'
			AND m001.status = status_acc.value_id
    WHERE m001.del_flag = '0'
    AND m001.role_id = 1
    AND m001.user_name LIKE CONCAT('%', p_user_name ,'%') 
    LIMIT 20
    ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `list_gh` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `list_gh`(
	IN p_date_from DATE
)
BEGIN

	DECLARE total_row INT DEFAULT 0;
    DECLARE total_bit decimal(15,8) DEFAULT 0;
    
	SET @w_time = now();
	SET @three_day_ago_date = date_add(CURDATE(), INTERVAL - 2 DAY);
   
	SELECT  count(*), sum(amount) INTO total_row, total_bit
	FROM d002 
	WHERE d002.create_date < @three_day_ago_date 
    AND d002.create_date > p_date_from
	AND d002.`status` = 1;

	SELECT 
		d002.id,
		d002.user_id,
		m001.user_name,
		d002.amount,
		d002.create_date,
		DATEDIFF(@w_time, d002.create_date) AS day_ago,
		total_bit AS total_bit,
		total_row AS total
	FROM
		d002
			LEFT JOIN
		m001 ON d002.user_id = m001.user_id
	WHERE
		d002.create_date < @three_day_ago_date
	AND d002.create_date > p_date_from
	AND d002.`status` = 1
	LIMIT 0 , 20

	;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `map_downlinetree_get` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `map_downlinetree_get`(
 IN p_user_id INT
)
BEGIN
	DECLARE t_tree_id INT DEFAULT NULL;
	SELECT tree_id INTO t_tree_id FROM m005 where user_id = p_user_id;
	call get_branch(t_tree_id, NULL, '');-- return table tbl_result
    
	SELECT 
		tbl_result.tree_id,
        tbl_result.parent_tree_id,
        tbl_result.is_branch,
        tbl_result.lvl,
        tbl_result.cnt_children,
		m001.user_id,
        m001.user_name,
        m001.email,
        m001.phone,
        lib001.value AS rank_name,
		status_acc.value AS status_name,
        coalesce(dph.countph, 0) AS countph
	FROM
		tbl_result
			INNER JOIN
		m001 ON tbl_result.user_id = m001.user_id
			LEFT JOIN
		lib001 ON lib001.code = 'rank'
			AND m001.rank = lib001.value_id
			LEFT JOIN
		lib001 AS status_acc ON status_acc.code = 'status_acc'
			AND m001.status = status_acc.value_id
            LEFT JOIN (
				SELECT 
					count(d001.user_id) AS countph, d001.user_id
				FROM d001
				GROUP BY d001.user_id
            ) dph ON tbl_result.user_id = dph.user_id
	WHERE
		m001.del_flag = 0
	;
    
	DROP TEMPORARY TABLE IF EXISTS tbl_result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `map_referral_get` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `map_referral_get`(
 IN p_user_id INT
)
BEGIN
	DECLARE t_tree_id INT DEFAULT NULL;
	SELECT tree_id INTO t_tree_id FROM m005 where user_id = p_user_id;
	call get_branch(t_tree_id, 1, '');-- return table tbl_result
    
	SELECT 
		m001.*,
		lib001.value AS rank_name,
		status_acc.value AS status_name
	FROM
		tbl_result
			INNER JOIN
		m001 ON tbl_result.user_id = m001.user_id
			LEFT JOIN
		lib001 ON lib001.code = 'rank'
			AND m001.rank = lib001.value_id
			LEFT JOIN
		lib001 AS status_acc ON status_acc.code = 'status_acc'
			AND m001.status = status_acc.value_id
	WHERE
		m001.user_id <> p_user_id AND m001.del_flag = 0
	;
    
	DROP TEMPORARY TABLE IF EXISTS tbl_result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `msg_count_unread` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `msg_count_unread`(
	IN p_user_id BIGINT
)
BEGIN
	SELECT 
		COUNT(msg_id) AS count_msg
	FROM
		m006
	WHERE
		(m006.user_to_id = p_user_id AND m006.status < 2)
		OR (m006.user_to_id = - 1 AND JSON_SEARCH(m006.user_read, 'one', 1) IS NULL)
	;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `msg_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `msg_detail`(
	IN p_msg_id INT,
    IN p_user_id INT
)
BEGIN
	
    SELECT m006.*,
    @user_to_id:= m006.user_to_id,
    m001.user_name
    FROM m006
    LEFT JOIN m001 ON m006.user_from_id = m001.user_id
    WHERE m006.msg_id = p_msg_id
    AND (m006.user_to_id = p_user_id OR m006.user_to_id = -1);
    
    IF @user_to_id IS NOT NULL AND @user_to_id <> -1 
    THEN
		UPDATE m006 
        SET m006.status = 2
        WHERE m006.msg_id = p_msg_id ;
    END IF;
    
    IF @user_to_id = -1
    THEN
		UPDATE m006 
        SET m006.status = 3,
        m006.user_read = JSON_MERGE(coalesce(m006.user_read, '[]'), JSON_ARRAY(cast(p_user_id AS CHAR)))
        WHERE m006.msg_id = p_msg_id
        AND JSON_SEARCH(m006.user_read, 'one', p_user_id) IS NULL  
        ;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `msg_get_child` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `msg_get_child`(
	IN p_user_id INT
)
BEGIN
	SET @role_id = (SELECT role_id FROM m001 WHERE user_id = p_user_id );
    IF @role_id = 3 
    THEN
		SELECT m001.user_id
	,	m001.user_name
    FROM m001
    WHERE
		m001.del_flag = '0'
        AND m001.user_id <> p_user_id;
    ELSE
	SET @tree_id = (SELECT tree_id from m005 where user_id = p_user_id);
    call get_branch(@tree_id, 1, '');-- return table tbl_result
    
    
	SELECT 
    m001.user_id, m001.user_name
	FROM m001
	WHERE m001.del_flag = '0'
        AND m001.user_id <> p_user_id
        AND (m001.role_id = 3
        OR EXISTS( SELECT 
            1
        FROM
            tbl_result
        WHERE
            m001.user_id = tbl_result.user_id));
    DROP TEMPORARY TABLE IF EXISTS tbl_result;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `package_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `package_info`()
BEGIN
	SELECT * FROM m002;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pin_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`m5`@`%` PROCEDURE `pin_info`(
	IN p_user_id INT
)
BEGIN
	-- get pin
    SELECT pin FROM m003 WHERE m003.user_id = p_user_id AND del_flag = 0;
    
    -- get history tranfer pin
	SELECT 
    m004.id,
    m004.user_id,
    m004.balance_pin,
    m004.user_id_from,
    m004.pin_tranfer,
    m004.description,
    m004.type,
    m004.create_date,
    m004.update_date,
    m001.user_name AS tranfer_user_name,
    lib001.value AS name_tranfer
	FROM
		m004
			LEFT JOIN
		lib001 ON lib001.code = 'type_pin'
			AND m004.type = lib001.value_id
			LEFT JOIN
		m001 ON m004.user_id_from = m001.user_id
	WHERE
		m004.user_id = p_user_id
			AND m004.del_flag = 0
	ORDER BY m004.create_date DESC
	LIMIT 15;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pin_request_token` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `pin_request_token`(
    IN p_token   INT,
	IN p_pin_cost NUMERIC(15,8),
    IN p_user_id INT,
    IN p_ip	VARCHAR(50)
)
BEGIN
  
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT 1, @p1, @p2;
        
		SELECT * FROM tbl_respon;
        ROLLBACK;
    END;
    
    START TRANSACTION;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		id INT(11) NULL default 0
	,	code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
    
	set @w_time = now();
    set @balance_pin = p_token;
    set @btc = p_token * p_pin_cost;
    
    -- select  @btc , p_token, p_pin_cost;
    IF EXISTS (SELECT 1 FROM m003 where m003.user_id = p_user_id) 
	THEN 
    
		update m003
		set ip_update = p_ip 
		, update_date = @w_time
		, pin = @balance_pin := pin + p_token
        , user_updated_id = p_user_id
		where m003.user_id = p_user_id;
        
	ELSE 
		
		INSERT INTO m003 (
			user_id,
            pin,
            user_created_id,
            ip_create,
            create_date
		)
		SELECT p_user_id, p_token, p_user_id, p_ip, @w_time;
	END IF;

	INSERT INTO m004 (
		user_id,
        balance_pin,
        pin_tranfer,
        type,
        ip_create,
        create_date
    )
    VALUES ( p_user_id, @balance_pin, p_token, 5, p_ip, @w_time);
    
    -- update bitcoin
    SELECT COALESCE(balance_in, 0),
		COALESCE(withdrawable1, 0),
        COALESCE(withdrawable2, 0),
		COALESCE(sponsor_bonus, 0),
		COALESCE(manager_bounus, 0)
    INTO @u_balance_in, @withdrawable1, @withdrawable2, @u_sponsor_bous, @u_manager_bous
    FROM w001 WHERE user_id = p_user_id;
    
    IF (@u_balance_in >= @btc)
		THEN
			SET	@u_balance_in = @u_balance_in - @btc;
	ELSEIF((@u_balance_in + @u_sponsor_bous) >= @btc)
		THEN
			SET @u_balance_in = 0;
            SET @u_sponsor_bous = @u_sponsor_bous + @u_balance_in - @btc;
	ELSEIF((@u_balance_in + @u_sponsor_bous + @u_manager_bous) >= @btc)
		THEN
			SET @u_balance_in = 0;
            SET @u_sponsor_bous = 0;
            SET @u_manager_bous = @u_manager_bous + @u_sponsor_bous + @u_balance_in - @btc;
    ELSEIF((@u_balance_in + @u_sponsor_bous + @u_manager_bous + @withdrawable1) >= @btc)
		THEN
			SET @u_balance_in = 0;
            SET @u_sponsor_bous = 0;
            SET @u_manager_bous = 0;
            SET @withdrawable1 = @withdrawable1 + @u_manager_bous + @u_sponsor_bous + @u_balance_in - @btc; 
	ELSEIF((@u_balance_in + @u_sponsor_bous + @u_manager_bous + @withdrawable1 +  @withdrawable2) >= @btc)
		THEN
			SET @u_balance_in = 0;
            SET @u_sponsor_bous = 0;
            SET @u_manager_bous = 0;
            SET @withdrawable1 = 0;
            SET @withdrawable2 = @withdrawable2 + @withdrawable1 + @u_manager_bous + @u_sponsor_bous + @u_balance_in - @btc;
    ELSE
		INSERT INTO tbl_respon
		SELECT 1, '1', 'Insufficient funds!';
    END IF;
    
    UPDATE w001
	SET balance_in = @u_balance_in,
		-- r_wallet = r_wallet - @btc,
		sponsor_bonus = @u_sponsor_bous,
		manager_bounus = @u_manager_bous,
        withdrawable1 = @withdrawable1,
        withdrawable2 = @withdrawable2,
		update_date = @w_time,
		ip_update = p_ip
	WHERE user_id = p_user_id
	AND del_flag = '0';
    
    
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
        ROLLBACK;
	ELSE 
		COMMIT;
		SELECT '1' AS success;
	END IF;
    DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pin_send_token` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `pin_send_token`(
	IN p_user_id INT,
    IN p_token   INT,
    IN p_user_id_to INT,
    IN p_ip	VARCHAR(50)
)
BEGIN
  
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT 1, @p1, @p2;
          
    END;
    
    START TRANSACTION;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		id INT(11) NULL default 0
	,	code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
    
	set @w_time = now();
    
	update m003
	set ip_update = p_ip 
    , update_date = @w_time
    , pin = pin - p_token
    , user_updated_id = p_user_id_to
	where m003.user_id = p_user_id_to;
    
    IF EXISTS (SELECT 1 FROM m003 where m003.user_id = p_user_id) 
	THEN 
		update m003
		set ip_update = p_ip 
		, update_date = @w_time
		, pin = pin + p_token
		, user_updated_id = p_user_id_to
		where m003.user_id = p_user_id;
	ELSE 
		INSERT INTO m003 (
			user_id,
            pin,
            user_created_id,
            ip_create,
            create_date
		)
		SELECT p_user_id, p_token, p_user_id_to, p_ip, @w_time;
	END IF;
    

	INSERT INTO m004 (
		user_id,
        user_id_from,
        pin_tranfer,
        type,
        ip_create,
        create_date
    )
    VALUES ( p_user_id, p_user_id_to, p_token, 2, p_ip, @w_time),
		   ( p_user_id_to, p_user_id, p_token, 1, p_ip, @w_time);


	update m004
    INNER JOIN m003 ON m004.user_id = m003.user_id
    SET  balance_pin = m003.pin
    where m004.user_id IN (p_user_id, p_user_id_to)
    ;
    
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
        ROLLBACK;
	ELSE 
		COMMIT;
		SELECT '1' AS success;
	END IF;
    DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `provide_before_save` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `provide_before_save`(
    IN p_package_id   INT,
    IN p_bitcoin  NUMERIC(10,2),
    IN p_user_id INT,
    IN p_balance DOUBLE(15,8)

)
BEGIN

	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
     
	set @w_time = now();
    
	IF NOT EXISTS(SELECT 1 FROM w001 WHERE user_id = p_user_id)
    THEN
		INSERT INTO w001 (
			user_id,
            balance_in
        )
        SELECT p_user_id, 0;
    END IF;
    
	update w001 
	SET balance_in = COALESCE(balance_in, 0) + COALESCE(p_balance, 0)
	WHERE user_id = p_user_id;
    
    -- check exists package
    IF NOT EXISTS (SELECT 1 FROM m002 
		WHERE m002.id = p_package_id
			AND m002.`start` <= p_bitcoin
            AND m002.`end`    >= p_bitcoin
            AND m002.del_flag = '0'
	) 
	THEN 
		INSERT INTO tbl_respon
		SELECT '0', 'Not found package!';

	END IF;
    
    -- check pin enough
    SET @pin = (SELECT pin_cost FROM m002 WHERE m002.id = p_package_id LIMIT 1);
    IF NOT EXISTS (SELECT 1 FROM m003 
		WHERE m003.user_id = p_user_id
            AND m003.del_flag = '0'
            AND m003.pin >=  @pin
	) 
	THEN 
		INSERT INTO tbl_respon
		SELECT '1', 'Not enough pin!';

	END IF;

	-- check enough bitcoi
    IF EXISTS (SELECT 1 FROM w001 
		WHERE w001.user_id = p_user_id
			AND w001.del_flag = '0'
            AND (COALESCE(balance_in, 0) + COALESCE(withdrawable1, 0) + COALESCE(withdrawable2, 0) 
            +COALESCE(sponsor_bonus, 0) + COALESCE(manager_bounus, 0)) < p_bitcoin
	) 
	THEN 
		INSERT INTO tbl_respon
		SELECT '2', 'Insufficient funds!';

	END IF;
    
    -- check max ph in month
    SET @max_bit_month = (SELECT sys_value FROM s002 WHERE sys_name = 'max_bit_month' LIMIT 1);
    
    IF @max_bit_month IS NOT NULL
    THEN
		SET @total_amount = (SELECT sum(amount) from d001 
								where user_id = p_user_id
								AND create_date > date_add(@w_time ,interval -DAY(@w_time) + 1 DAY)
								AND create_date < date_add(LAST_DAY(@w_time), INTERVAL + 1 DAY));
                              
                                
		IF (@total_amount*1 + p_bitcoin)  >  @max_bit_month*1
        THEN
			INSERT INTO tbl_respon
			SELECT '3',  CONCAT('Max: ',@max_bit_month,' bit in month');
        END IF;
        
    END IF;
    
    
    
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
	ELSE 
		SELECT '1' AS success;
	END IF;
    
    DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `provide_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `provide_info`(
	IN p_user_id INT
)
BEGIN
	SELECT 
		d001.user_id,
		d001.amount,
		d001.status,
        lib001.value AS status_name,
        d001.package_id,
        m002.package_name,
		d001.get_profit_date,
        d001.rate,
		d001.create_date,
		d001.update_date
	FROM d001
    LEFT JOIN
		lib001 ON lib001.code = 'status_dnt_ph'
			AND d001.status = lib001.value_id
	LEFT JOIN m002 ON d001.package_id = m002.id
    WHERE d001.del_flag = 0
    AND d001.user_id = p_user_id
    AND EXISTS( SELECT 1 FROM m001 WHERE m001.user_id = p_user_id AND m001.del_flag = 0 AND m001.status = 1)
    ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `provide_package` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `provide_package`(

)
BEGIN
	SELECT 
		m002.id,
        m002.package_name,
        m002.`start`,
        m002.`end`,
        m002.distance,
		m002.interest_rate,
		m002.pin_cost
	FROM m002
    WHERE m002.del_flag = '0'
    ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `provide_save_ph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `provide_save_ph`(
	IN p_package_id   INT,
    IN p_bitcoin  NUMERIC(10,2),
    IN p_user_id INT,
    IN p_ip	VARCHAR(50)
)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		
        INSERT INTO tbl_respon
		SELECT @p1, @p2;
		SELECT * FROM tbl_respon;
		ROLLBACK;
          
    END;
    
    START TRANSACTION;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
    
	SET @w_time = now();
	SET @rate_f1 = (SELECT sys_value FROM s002 WHERE sys_name = 'sponsor_interest_rate' LIMIT 1);
    SET @mng2 = (SELECT sys_value FROM s002 WHERE sys_name = 'mng2' LIMIT 1);
    SET @mng3 = (SELECT sys_value FROM s002 WHERE sys_name = 'mng3' LIMIT 1);
    SET @mng4 = (SELECT sys_value FROM s002 WHERE sys_name = 'mng4' LIMIT 1);
    SET @mng5 = (SELECT sys_value FROM s002 WHERE sys_name = 'mng5' LIMIT 1);
	SET @day_after = (SELECT ceil(max_rate / interest_rate) FROM m002 WHERE m002.id = p_package_id LIMIT 1);
	
	INSERT INTO d001 (
		user_id,
		package_id,
		amount,
		`status`,
		get_profit_date,
        rate,
        max_rate,
        save_bit_rate,
		ip_create,
		create_date
	)
    SELECT p_user_id, 
    p_package_id,
    p_bitcoin,
    1,
    adddate(@w_time, INTERVAL @day_after DAY), 
    rate, 
    max_rate,
    save_bit_rate,
    p_ip,
    @w_time
    FROM m002 WHERE m002.id = p_package_id;
	-- VALUES ( p_user_id, p_package_id, p_bitcoin, 1, adddate(@w_time, INTERVAL @day_after DAY),p_ip, @w_time);

	SET @pin = (SELECT pin_cost FROM m002 WHERE m002.id = p_package_id LIMIT 1);
	
	-- update pin/token
	UPDATE m003
	set ip_update = p_ip 
	, update_date = @w_time
	, pin = @balance_pin := pin - @pin
	, user_updated_id = p_user_id
	where m003.user_id = p_user_id;
	
	-- history pin
	INSERT INTO m004 (
	user_id,
	balance_pin,
	pin_tranfer,
	type,
	ip_create,
	create_date
	)
	VALUES ( p_user_id, @balance_pin, @pin, 4, p_ip, @w_time);
	
	-- update balnace
    SELECT COALESCE(balance_in, 0),
		COALESCE(withdrawable1, 0),
        COALESCE(withdrawable2, 0),
		COALESCE(sponsor_bonus, 0),
		COALESCE(manager_bounus, 0)
    INTO @u_balance_in,  @u_withdrawable1, @u_withdrawable2, @u_sponsor_bous, @u_manager_bous
    FROM w001 WHERE user_id = p_user_id;
    
    IF (@u_balance_in >= p_bitcoin)
		THEN
			SET	@u_balance_in = @u_balance_in - p_bitcoin;
	ELSEIF((@u_balance_in + @u_sponsor_bous) >= p_bitcoin)
		THEN
			SET @u_balance_in = 0;
            SET @u_sponsor_bous = @u_sponsor_bous + @u_balance_in - p_bitcoin;
	ELSEIF((@u_balance_in + @u_sponsor_bous + @u_manager_bous) >= p_bitcoin)
		THEN
			SET @u_balance_in = 0;
            SET @u_sponsor_bous = 0;
            SET @u_manager_bous = @u_manager_bous + @u_sponsor_bous + @u_balance_in - p_bitcoin;
    ELSEIF((@u_balance_in + @u_sponsor_bous + @u_manager_bous + @u_withdrawable1) >= p_bitcoin)
		THEN
			SET @u_balance_in = 0;
            SET @u_sponsor_bous = 0;
            SET @u_manager_bous = 0;
            SET @u_withdrawable1 = @u_withdrawable1 + @u_manager_bous + @u_sponsor_bous + @u_balance_in - p_bitcoin; 
	ELSEIF((@u_balance_in + @u_sponsor_bous + @u_manager_bous + @u_withdrawable1 + @u_withdrawable2) >= p_bitcoin)
		THEN
			SET @u_balance_in = 0;
            SET @u_sponsor_bous = 0;
            SET @u_manager_bous = 0;
            SET @u_withdrawable1 = 0;
            SET @u_withdrawable2 = @u_withdrawable1 + @u_withdrawable1 + @u_manager_bous + @u_sponsor_bous + @u_balance_in - p_bitcoin; 
	ELSE
		INSERT INTO tbl_respon
		SELECT '1', 'Insufficient funds!';
    END IF;
    
	UPDATE w001
	SET balance_in = @u_balance_in,
		withdrawable1 = @u_withdrawable1,
        withdrawable2 = @u_withdrawable2,
		sponsor_bonus = @u_sponsor_bous,
		manager_bounus = @u_manager_bous,
		update_date = @w_time,
		ip_update = p_ip
	WHERE user_id = p_user_id
	AND del_flag = '0';


	-- update interest rate for parent (sponosor vs manager)
    SELECT tree_id, lvl INTO @tree_id, @user_lvl FROM m005 WHERE m005.user_id = p_user_id LIMIT 1;
	call table_tree_get_parents(@tree_id);-- return tree_parents
	
    -- update from f1
	SET @parent_user_id = (SELECT user_id FROM tree_parents WHERE tree_parents.lvl = @user_lvl - 1);
	IF @parent_user_id IS NOT NULL THEN
		UPDATE w001
		SET sponsor_bonus = sponsor_bonus + p_bitcoin*@rate_f1/100
		WHERE w001.user_id = @parent_user_id;
	
	END IF;
    
    -- update manager interest rate
    SET @user_rank = (SELECT rank FROM m001 WHERE m001.user_id = p_user_id);
    SET @interest = CASE @user_rank
						WHEN 1 THEN 0
                        WHEN 2 THEN @mng2
                        WHEN 3 THEN @mng3
                        WHEN 4 THEN @mng4
                        WHEN 5 THEN @mng5
					END;
	UPDATE w001
    INNER JOIN tree_parents ON  w001.user_id = tree_parents.user_id
    SET manager_bounus = manager_bounus + p_bitcoin * @interest/100
    WHERE  w001.user_id <> @parent_user_id
    ;
	
    
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
		ROLLBACK;
	ELSE 
		COMMIT;
		SELECT '1' AS success;
	END IF;
	DROP TEMPORARY TABLE IF EXISTS tbl_respon;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rate_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `rate_info`()
BEGIN
	SELECT * FROM s002;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `referral_add_to_tree` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `referral_add_to_tree`(
    IN p_parent_id INT,
    IN p_child_user_id INT,
    IN p_user_id INT,
    IN p_ip	VARCHAR(50)
)
BEGIN

	DECLARE t_node_found INT DEFAULT NULL;
	DECLARE t_node_lft INT DEFAULT NULL;
	DECLARE t_node_rht INT DEFAULT NULL;
	DECLARE t_node_lvl MEDIUMINT DEFAULT NULL;

	set @w_time = now();
    IF EXISTS (SELECT 1 FROM m001 WHERE m001.del_flag = '0' AND m001.user_id = p_parent_id) 
    THEN
		IF NOT EXISTS(SELECT 1 FROM m005 WHERE m005.user_id = p_child_user_id)
        THEN
			SET @parent_tree_id = ( SELECT 
										m005.tree_id 
									FROM m005
									WHERE EXISTS (SELECT 1 FROM m001 WHERE m005.user_id = m001.user_id AND m001.user_id = p_parent_id)
									LIMIT 1
									);
                                    
            SELECT tree_id, lft , rht ,lvl INTO t_node_found, t_node_lft, t_node_rht, t_node_lvl
			FROM m005
			WHERE tree_id = @parent_tree_id;
            
            SET @count_child = ( SELECT count(tree_id)
								 FROM m005
								 WHERE lft >= t_node_lft
								   AND lft < t_node_rht
								   AND lvl = t_node_lvl + 1
								 ORDER BY lft
								 LIMIT 0,2
								 );
            IF  @count_child < 6
            THEN
                     
				IF EXISTS (SELECT 1 FROM m001 WHERE m001.del_flag = '0' AND m001.user_id = p_child_user_id)
				THEN
					SET @child_user_name  = (SELECT user_name FROM m001 WHERE m001.user_id = p_child_user_id);
					call tree_add_node(@parent_tree_id, p_child_user_id, @child_user_name, '');
				ELSE
					INSERT INTO tbl_respon
					SELECT 3, '02', 'Child user not exist';
				END IF;
			ELSE
				INSERT INTO tbl_respon
				SELECT 5, '05', 'Has 6 child';
            END IF;
            
		ELSE
			INSERT INTO tbl_respon
			SELECT 4, '03', 'Child user added';
        END IF;
        
		
	ELSE
		 INSERT INTO tbl_respon
		 SELECT 2, '01', 'Parent User Name not exist';
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `register_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `register_user`(
-- 	   IN p_parent_user_id INT,
--     IN p_user_id INT,
--     IN p_user_name varchar(255),
--     IN p_wallet_adress VARCHAR(255),
--     IN p_ip_create VARCHAR(45)
	IN p_data JSON
    
)
proc: BEGIN
	
    DECLARE e_exists_user_name CONDITION FOR SQLSTATE '45000';
	DECLARE e_exists_email CONDITION FOR SQLSTATE '45000';
    DECLARE e_not_exists_parent CONDITION FOR SQLSTATE '45000';
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		GET DIAGNOSTICS CONDITION 1
        @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
		ROLLBACK;
        
		INSERT INTO tbl_respon
		SELECT 1, @p1, @p2;
        
        SELECT * FROM tbl_respon;
               
	END;
    
	DROP TEMPORARY TABLE IF EXISTS tbl_respon;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_respon (
		id INT(11) NULL default 0
	,	code_exp VARCHAR(50) NULL default ''
    ,	msg VARCHAR(200) NULL default ''
    );
	SET @w_time = now();
    
    -- Validate the parent (node_id)
	IF EXISTS(SELECT 1 FROM m001 WHERE user_name =  JSON_UNQUOTE(json_extract(p_data, "$.user_name"))) 
    THEN
		SIGNAL e_exists_user_name
			SET MESSAGE_TEXT = 'exists_user_name';
		LEAVE proc;
	END IF;
    
    IF EXISTS(SELECT 1 FROM m001 WHERE email =  JSON_UNQUOTE(json_extract(p_data, "$.email"))) 
    THEN
		SIGNAL e_exists_email
			SET MESSAGE_TEXT = 'exists_email';
		LEAVE proc;
	END IF;
    
    IF EXISTS(SELECT 1 FROM m001 
				INNER JOIN m005 ON m001.user_id = m005.user_id
				WHERE m001.user_name =  JSON_UNQUOTE(json_extract(p_data, "$.parent_name"))) 
    THEN
		SET @parent_id = (SELECT user_id FROM m001 WHERE m001.user_name = JSON_UNQUOTE(json_extract(p_data, "$.parent_name")) LIMIT 1);
        SET @parent_tree_id = (SELECT tree_id FROM m005 WHERE m005.user_id = @parent_id);
	ELSE
		IF JSON_UNQUOTE(json_extract(p_data, "$.parent_name")) IS NULL OR JSON_UNQUOTE(json_extract(p_data, "$.parent_name")) = ''
		THEN
			 SET @parent_id = 2;
             SET @parent_tree_id = 3;
        ELSE
			SIGNAL e_not_exists_parent
			SET MESSAGE_TEXT = 'not_exists_parent';
			LEAVE proc;
        END IF;
	END IF;
    
	START TRANSACTION;
		INSERT INTO m001(
			user_name
		,	full_name
        ,	parent_user_id
        ,	wallet
        ,	email
        ,	phone
        ,	`password`
        ,	t_password
        ,	role_id
        ,	rank
        ,	`status`
        ,	ip_create
        ,	create_date
        )
		SELECT 
          JSON_UNQUOTE(json_extract(p_data, "$.user_name"))
		, JSON_UNQUOTE(json_extract(p_data, "$.full_name"))
        , @parent_id
        , JSON_UNQUOTE(json_extract(p_data, "$.wallet"))
        , JSON_UNQUOTE(json_extract(p_data, "$.email")) 
        , JSON_UNQUOTE(json_extract(p_data, "$.mobile")) 
        , JSON_UNQUOTE(json_extract(p_data, "$.password")) 
        , JSON_UNQUOTE(json_extract(p_data, "$.t_password")) 
        , JSON_UNQUOTE(json_extract(p_data, "$.role_id"))
        , JSON_UNQUOTE(json_extract(p_data, "$.rank"))
        , JSON_UNQUOTE(json_extract(p_data, "$.status"))
        , JSON_UNQUOTE(json_extract(p_data, "$.ip_create"))
        ,  @w_time;
        
        SELECT LAST_INSERT_ID() INTO @user_id_last;

		call tree_add_node(@parent_tree_id, @user_id_last, JSON_UNQUOTE(json_extract(p_data, "$.user_name")), '');
		call update_rank_by_user_id(JSON_UNQUOTE(json_extract(p_data, "$.parent_id"))); 
        
        INSERT INTO btc001
			(
				user_id,
				btc_address,
				btc_label,
				ip_create
				
            )
        SELECT @user_id_last
        , JSON_UNQUOTE(json_extract(p_data, "$.wallet_address"))
        , JSON_UNQUOTE(json_extract(p_data, "$.user_name"))
        , JSON_UNQUOTE(json_extract(p_data, "$.ip_create"));
        
	IF EXISTS (SELECT 1 FROM tbl_respon) 
	THEN 
		SELECT * FROM tbl_respon;
        ROLLBACK;
	ELSE 
		COMMIT;
		-- SELECT '1' AS success;
	END IF;
    
    DROP TEMPORARY TABLE IF EXISTS tbl_respon;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `system_add_resource` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `system_add_resource`(
	IN p_module VARCHAR(200),
    IN p_ctrl VARCHAR(200),
    IN p_act VARCHAR(200)
)
BEGIN
	IF EXISTS(SELECT 1 FROM acl WHERE module = p_module AND controller = p_ctrl AND action = p_act)
    THEN 
		SELECT 1;
	ELSE 
		INSERT INTO acl (module, controller, action)
        VALUES(p_module, p_ctrl, p_act);
		
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `table_tree_get_parents` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `table_tree_get_parents`(
     IN p_id INT
    )
proc: BEGIN

        -- Declare variables
        DECLARE e_no_id CONDITION FOR SQLSTATE '45000';
        DECLARE e_id_not_found  CONDITION FOR SQLSTATE '45000';
        DECLARE v_node_found INT DEFAULT NULL;
        DECLARE v_node_lft INT DEFAULT NULL;
        
		DROP TEMPORARY TABLE IF EXISTS tree_parents;
		CREATE TEMPORARY TABLE IF NOT EXISTS tree_parents (
			tree_id INT NULL
		,	user_id INT NULL 
        ,	lvl INT NULL
        );
        
        -- Validate the tree_id
        IF (p_id IS NULL) THEN
            SIGNAL e_no_id
                SET MESSAGE_TEXT = 'The id cannot be empty.';
            LEAVE proc;
        END IF;
        SELECT tree_id, lft INTO v_node_found, v_node_lft
          FROM m005
         WHERE tree_id = p_id;

        IF ( v_node_found IS NULL) THEN
            SIGNAL e_id_not_found
                SET MESSAGE_TEXT = 'The tree_id does not exists.';
            LEAVE proc;
        END IF;

        -- select the parents
        INSERT INTO tree_parents
        SELECT a.tree_id
             , a.user_id
             , a.lvl
          FROM m005 a, m005 b
         WHERE b.tree_id = p_id
           AND a.tree_id <> p_id
           AND b.lft BETWEEN a.lft AND a.rht
           AND a.lvl > 0
             ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_add_node` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_add_node`(
     IN p_parent INT
    ,IN p_user_id VARCHAR(50)
    ,IN p_user_name VARCHAR(100)
    ,IN p_description VARCHAR(500)
    )
proc: BEGIN

        -- Declare variables
        DECLARE e_user_id_already_exists CONDITION FOR SQLSTATE '45000';
        DECLARE e_user_id_is_empty CONDITION FOR SQLSTATE '45000';
        DECLARE e_no_parent CONDITION FOR SQLSTATE '45000';
        DECLARE e_parent_not_found  CONDITION FOR SQLSTATE '45000';
        DECLARE v_parent_found INT DEFAULT 0;
        DECLARE v_found_user_id INT DEFAULT NULL;
        DECLARE v_user_name VARCHAR(100) DEFAULT NULL;
        DECLARE v_description VARCHAR(500) DEFAULT NULL;
        DECLARE v_parent_lft INT DEFAULT NULL;
        DECLARE v_parent_rht INT DEFAULT NULL;
        DECLARE v_parent_lvl MEDIUMINT DEFAULT NULL;
        DECLARE v_new_id INT DEFAULT NULL;

        -- Use default values if NULL is given as parameter
        SET v_user_name := COALESCE( p_user_name, p_user_id);
        SET v_description := COALESCE( p_description, v_description);

        -- Validate the parent (node_id)
        IF ( p_parent IS NULL) THEN
            SIGNAL e_no_parent
                SET MESSAGE_TEXT = 'The id of the parent node cannot be empty.';
            LEAVE proc;
        END IF;
        SELECT tree_id, lft , rht ,lvl INTO v_parent_found, v_parent_lft, v_parent_rht, v_parent_lvl
          FROM m005
         WHERE tree_id = p_parent;

        IF ( v_parent_found IS NULL) THEN
            SIGNAL e_parent_not_found
                SET MESSAGE_TEXT = 'The tree_id of the parent does not exists.';
            LEAVE proc;
        END IF;

        -- Validate the user_id of the node
        IF ( p_user_id IS NULL) OR ( p_user_id = '') THEN
            SIGNAL e_user_id_already_exists
                SET MESSAGE_TEXT = 'The user_id of the node cannot be empty.';
            LEAVE proc;
        END IF;

        -- check if the user_id already exists in this branch
        SELECT 1
          INTO v_found_user_id
          FROM m005
         WHERE lft >= v_parent_lft
           AND lft <  v_parent_rht
           AND lvl =  v_parent_lvl + 1
           AND user_id LIKE BINARY p_user_id ;

        IF v_found_user_id <> 0 THEN
            SIGNAL e_user_id_already_exists
               SET MESSAGE_TEXT = 'A node whith the exact same user_id already exists in this branch';
               LEAVE proc;
        END IF;

        -- insert the new node
        SET SQL_SAFE_UPDATES=0;
        START TRANSACTION;
            -- make some room in the tree
            UPDATE m005 SET lft = CASE WHEN lft >  v_parent_rht THEN lft + 2 ELSE lft END
                            ,rht = CASE WHEN rht >= v_parent_rht THEN rht + 2 ELSE rht END
             WHERE rht >= v_parent_rht;
            -- insert
            INSERT INTO m005 (user_id, user_name, description, lft, rht, lvl)
                 VALUES ( p_user_id , v_user_name, v_description , v_parent_rht , v_parent_rht + 1,v_parent_lvl + 1);

            SELECT LAST_INSERT_ID() INTO v_new_id;
        COMMIT;
		SET SQL_SAFE_UPDATES=1;
        -- return the inserted id
        SELECT v_new_id AS tree_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_add_root` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_add_root`()
proc: BEGIN

        -- Declare variables
        DECLARE e_table_not_empty CONDITION FOR SQLSTATE '45000';
        DECLARE v_found INT DEFAULT 0;

        -- Make sure the table is empty
        SELECT COUNT(1) INTO v_found FROM m005;
        IF v_found <> 0 THEN
            SIGNAL e_table_not_empty
                SET MESSAGE_TEXT = 'The table should be empty before adding a root node.';
            LEAVE proc;
        END IF;

        -- insert root node
        INSERT INTO m005 (user_id, description, user_name, lft, rht,lvl)
            VALUES (0  , NULL , 'Root', 1 , 2 ,0);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_del` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_del`(
     IN p_id INT
    )
proc: BEGIN

        -- Declare variables
        DECLARE e_no_id CONDITION FOR SQLSTATE '45000';
        DECLARE e_id_not_found  CONDITION FOR SQLSTATE '45000';
        DECLARE v_node_found INT DEFAULT NULL;
        DECLARE v_node_lft INT DEFAULT NULL;
        DECLARE v_node_rht INT DEFAULT NULL;
        DECLARE v_node_lvl MEDIUMINT DEFAULT NULL;
        DECLARE v_node_tmp INT DEFAULT NULL;

        -- Validate the tree_id
        IF ( p_id IS NULL) THEN
            SIGNAL e_no_id
                SET MESSAGE_TEXT = 'The id cannot be empty.';
            LEAVE proc;
        END IF;

        SELECT tree_id, lft , rht ,lvl INTO v_node_found, v_node_lft, v_node_rht, v_node_lvl
          FROM m005
         WHERE tree_id = p_id;

        IF ( v_node_found IS NULL) THEN
            SIGNAL e_id_not_found
                SET MESSAGE_TEXT = 'The tree_id does not exists.';
            LEAVE proc;
        END IF;

        -- Start deleting
        SET SQL_SAFE_UPDATES=0;
        START TRANSACTION;
            -- Delete the node and the children if they exist
            DELETE
              FROM m005
             WHERE lft >= v_node_lft
               AND lft < v_node_rht
               AND rht <= v_node_rht
               AND lvl >= v_node_lvl;

            -- update the parents
               SET v_node_tmp = ((v_node_rht - v_node_lft) + 1);
            UPDATE m005
               SET lft = CASE WHEN lft > v_node_lft THEN lft - v_node_tmp ELSE lft END
                  ,rht = CASE WHEN rht > v_node_lft THEN rht - v_node_tmp ELSE rht END
             WHERE rht > v_node_rht;
        COMMIT;
        SET SQL_SAFE_UPDATES=1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_get_all` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_get_all`(
     IN p_depth TINYINT
    ,IN p_indent VARCHAR(20)
    )
proc: BEGIN
        CALL tree_get_branch(1,p_depth,p_indent);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_get_branch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_get_branch`(
     IN p_id INT
    ,IN p_depth TINYINT
    ,IN p_indent VARCHAR(20)
    )
proc: BEGIN

        -- Declare variables
        DECLARE e_no_id CONDITION FOR SQLSTATE '45000';
        DECLARE e_id_not_found  CONDITION FOR SQLSTATE '45000';
        DECLARE v_node_found INT DEFAULT NULL;
        DECLARE v_node_lft INT DEFAULT NULL;
        DECLARE v_node_rht INT DEFAULT NULL;
        DECLARE v_node_lvl MEDIUMINT DEFAULT NULL;
        DECLARE v_indent VARCHAR(20) DEFAULT NULL;
        DECLARE v_depth TINYINT DEFAULT 127;

        -- Validate the tree_id
        IF ( p_id IS NULL) THEN
            SIGNAL e_no_id
                SET MESSAGE_TEXT = 'The id cannot be empty.';
            LEAVE proc;
        END IF;
        SELECT tree_id, lft , rht ,lvl INTO v_node_found, v_node_lft, v_node_rht, v_node_lvl
          FROM m005
         WHERE tree_id = p_id;

        IF ( v_node_found IS NULL) THEN
            SIGNAL e_id_not_found
                SET MESSAGE_TEXT = 'The tree_id does not exists.';
            LEAVE proc;
        END IF;

        -- Use default values if NULL is given as parameter
        SET v_indent := COALESCE( p_indent, '');
        SET v_depth := COALESCE( p_depth, v_depth);

        -- select the branch
        SELECT tree_id
             , user_id
             , CONCAT(REPEAT( v_indent, (lvl - v_node_lvl) ), user_name) AS user_name
             , description
             , lvl
             , FORMAT((((rht - lft) -1) / 2),0) AS cnt_children
            , CASE WHEN rht - lft > 1 THEN 1 ELSE 0 END AS is_branch
          FROM m005
         WHERE lft >= v_node_lft
           AND lft < v_node_rht
           AND lvl <= v_node_lvl + v_depth
         ORDER BY lft;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_get_branch_by_user_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_get_branch_by_user_id`(
     IN p_parentuser_id VARCHAR(50)
    ,IN p_user_id VARCHAR(50)
    ,IN p_depth TINYINT
    ,IN p_indent VARCHAR(20)
    )
proc: BEGIN

        -- Declare variables
        DECLARE e_no_relation CONDITION FOR SQLSTATE '45000';
        DECLARE v_tree_id INT DEFAULT NULL;

        -- Validate the parent user_id and the node user_id and if the node is a child of the parent
        SELECT b.tree_id INTO v_tree_id
          FROM m005 a, m005 b
         WHERE a.user_id LIKE BINARY p_parentuser_id
           AND b.user_id LIKE BINARY p_user_id
           AND a.user_id <> b.user_id
           AND b.lft BETWEEN a.lft AND a.rht
           AND a.lvl = b.lvl -1
         LIMIT 1
             ;

        IF ( v_tree_id IS NOT NULL ) THEN
            CALL tree_get_branch( v_tree_id , p_depth, p_indent);
        ELSE
            SIGNAL e_no_relation
                SET MESSAGE_TEXT = 'The nodeuser_id is not a direct child of the parentuser_id.';
            LEAVE proc;
        END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_get_parents` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_get_parents`(
     IN p_id INT
    ,IN p_indent VARCHAR(20)
    )
proc: BEGIN

        -- Declare variables
        DECLARE e_no_id CONDITION FOR SQLSTATE '45000';
        DECLARE e_id_not_found  CONDITION FOR SQLSTATE '45000';
        DECLARE v_node_found INT DEFAULT NULL;
        DECLARE v_node_lft INT DEFAULT NULL;
        DECLARE v_indent VARCHAR(20) DEFAULT NULL;

        -- Validate the tree_id
        IF (p_id IS NULL) THEN
            SIGNAL e_no_id
                SET MESSAGE_TEXT = 'The id cannot be empty.';
            LEAVE proc;
        END IF;
        SELECT tree_id, lft INTO v_node_found, v_node_lft
          FROM m005
         WHERE tree_id = p_id;

        IF ( v_node_found IS NULL) THEN
            SIGNAL e_id_not_found
                SET MESSAGE_TEXT = 'The tree_id does not exists.';
            LEAVE proc;
        END IF;

        -- Use default values if NULL is given as parameter
        SET v_indent := COALESCE( p_indent, '');

        -- select the parents
        SELECT a.tree_id
             , a.user_id
             , CONCAT(REPEAT( v_indent, a.lvl ), a.user_name) AS user_name
             , a.description
             , a.lvl
          FROM m005 a, m005 b
         WHERE b.tree_id = p_id
           AND a.tree_id <> p_id
           AND b.lft BETWEEN a.lft AND a.rht
             ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_swap_leafs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_swap_leafs`(
     IN p_id1 INT
    ,IN p_id2 INT
    )
proc: BEGIN
-- doi 2 node cho nhau
        -- Declare variables
        DECLARE e_no_id CONDITION FOR SQLSTATE '45000';
        DECLARE e_id_not_found  CONDITION FOR SQLSTATE '45000';
        DECLARE e_id_not_leaf  CONDITION FOR SQLSTATE '45000';
        DECLARE e_levels_not_equal  CONDITION FOR SQLSTATE '45000';
        DECLARE v_node_found INT DEFAULT NULL;
        DECLARE v_node1_lft INT DEFAULT NULL;
        DECLARE v_node1_rht INT DEFAULT NULL;
        DECLARE v_node1_lvl INT DEFAULT NULL;
        DECLARE v_node2_lft INT DEFAULT NULL;
        DECLARE v_node2_rht INT DEFAULT NULL;
        DECLARE v_node2_lvl INT DEFAULT NULL;

        -- Validate the tree_id for p_id1 and p_id2
        IF (p_id1 IS NULL OR p_id2 IS NULL) THEN
            SIGNAL e_no_id
                SET MESSAGE_TEXT = 'Both id1 and id2 needs to be provided as parameter.';
            LEAVE proc;
        END IF;

        SELECT tree_id, lft, rht, lvl INTO v_node_found, v_node1_lft, v_node1_rht, v_node1_lvl
          FROM m005
         WHERE tree_id = p_id1;

        IF ( v_node_found IS NULL) THEN
            SIGNAL e_id_not_found
                SET MESSAGE_TEXT = 'The tree_id for id1 does not exists.';
            LEAVE proc;
        END IF;

        SELECT tree_id, lft, rht, lvl INTO v_node_found, v_node2_lft, v_node2_rht, v_node2_lvl
          FROM m005
         WHERE tree_id = p_id2;

        IF ( v_node_found IS NULL) THEN
            SIGNAL e_id_not_found
                SET MESSAGE_TEXT = 'The tree_id for id2 does not exists.';
            LEAVE proc;
        END IF;

        IF ( v_node1_lvl <> v_node2_lvl ) THEN
            SIGNAL e_levels_not_equal
                SET MESSAGE_TEXT = 'You cannot change position between nodes with a different level.';
            LEAVE proc;
        END IF;

        IF ( v_node1_rht - v_node1_lft ) > 1 OR
           ( v_node2_rht - v_node2_lft ) > 1 THEN
            SIGNAL e_levels_not_equal
                SET MESSAGE_TEXT = 'You can only swap leafs. One or both of the nodes is a branch.';
            LEAVE proc;
        END IF;

        -- update the leafs
        START TRANSACTION;
            UPDATE m005
            SET   lft     = v_node2_lft
                , rht     = v_node2_rht
                , lvl     = v_node2_lvl
            WHERE tree_id = p_id1;

            UPDATE m005
            SET   lft     = v_node1_lft
                , rht     = v_node1_rht
                , lvl     = v_node1_lvl
            WHERE tree_id = p_id2;
        COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tree_update_node` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `tree_update_node`(
     IN p_id INT
    ,IN p_user_name VARCHAR(100)
    ,IN p_description VARCHAR(500)
    )
proc: BEGIN

        -- Declare variables
        DECLARE e_no_node CONDITION FOR SQLSTATE '45000';
        DECLARE e_node_not_found  CONDITION FOR SQLSTATE '45000';
        DECLARE v_node_found INT DEFAULT 0;
        DECLARE v_user_name VARCHAR(100) DEFAULT NULL;
        DECLARE v_description VARCHAR(500) DEFAULT NULL;

        -- Validate the node_id
        IF ( p_id IS NULL) THEN
            SIGNAL e_no_node
                SET MESSAGE_TEXT = 'The id of the node cannot be empty.';
            LEAVE proc;
        END IF;

        SELECT tree_id, user_name ,description INTO v_node_found, v_user_name, v_description
          FROM m005
         WHERE tree_id = p_id;

        IF ( v_node_found IS NULL) THEN
            SIGNAL e_node_not_found
                SET MESSAGE_TEXT = 'The tree_id does not exists.';
            LEAVE proc;
        END IF;

        -- Use old values if NULL is given as parameter
        SET v_user_name := COALESCE( p_user_name, v_user_name);
        SET v_description := COALESCE( p_description, v_description);

        -- update the node
        UPDATE m005
           SET user_name       = v_user_name
              ,description = v_description
         WHERE tree_id     = p_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_rank_by_user_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_rank_by_user_id`(
	IN p_user_id INT
)
BEGIN
	DECLARE n INT DEFAULT 0;
	DECLARE i INT DEFAULT 0;
	DECLARE t_tree_id INT DEFAULT NULL;
    DECLARE t_rank INT DEFAULT NULL;
    DECLARE t_user_id INT DEFAULT NULL;
    
	DROP TEMPORARY TABLE IF EXISTS tbl_rank;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_rank
	(	
		rank INT,
		count INT	
	);
	
    DROP TEMPORARY TABLE IF EXISTS tbl_parent;
	CREATE TEMPORARY TABLE IF NOT EXISTS tbl_parent
	(	tree_id INT,
		user_id INT,
		rank INT	
	);
    
    DROP TEMPORARY TABLE IF EXISTS tbl_tmp;
    CREATE TEMPORARY TABLE IF NOT EXISTS tbl_tmp
	(	tree_id INT,
		user_id INT
	);
    
    
	SELECT tree_id INTO t_tree_id FROM m005 where user_id = p_user_id;
    SELECT rank INTO t_rank FROM m001 where user_id = p_user_id;
    
    INSERT INTO tbl_tmp
	SELECT a.tree_id
		 , a.user_id
	  FROM m005 a, m005 b
	 WHERE b.tree_id = t_tree_id
	   -- AND a.tree_id <> t_tree_id
	   AND b.lft BETWEEN a.lft AND a.rht
       AND a.tree_id > 1
		 ;
         
	INSERT INTO tbl_parent
	SELECT tbl_tmp.tree_id
    ,	tbl_tmp.user_id
    ,	m001.rank
    FROM tbl_tmp
    INNER JOIN m001 ON tbl_tmp.user_id = m001.user_id AND m001.del_flag = 0 AND m001.status = 1;
    
	SELECT COUNT(*) FROM tbl_parent INTO n;

	SET i=0;
	WHILE i<n DO 
     	
        SELECT tree_id, rank, user_id INTO @tree_id, @rank, @user_id FROM tbl_parent LIMIT i,1;
	
		call get_branch(@tree_id, 1, '');-- return table tbl_result
		
		INSERT INTO tbl_rank
		SELECT 
			m001.rank,
			count(m001.rank)
		FROM tbl_result
			INNER JOIN m001 ON tbl_result.user_id = m001.user_id	
		WHERE
			m001.del_flag = 0
			AND m001.status = 1
			AND m001.user_id <> @user_id
		GROUP BY m001.rank
		;
		
	  
		-- TRUNCATE TABLE tbl_rank;
	    IF (@rank  = 0) THEN
			
			set @cnt = (SELECT count FROM tbl_rank where rank >= 0 );
			IF (@cnt >5) THEN 
				UPDATE m001 SET rank = 1 
				where m001.user_id = @user_id;
			END IF;
			
		END IF;
       
		IF (@rank  = 1) THEN
			
			set @cnt = (SELECT count FROM tbl_rank where rank >= 1 );
			IF (@cnt >2) THEN 
				UPDATE m001 SET rank = 2 
				where m001.user_id = @user_id;
			END IF;
			
		END IF;
		
		IF (@rank  = 2) THEN
			
			set @cnt = (SELECT count FROM tbl_rank where rank >= 2 );
			IF (@cnt >2) THEN 
				UPDATE m001 SET rank = 3
				where m001.user_id = @user_id;
			END IF;
			
		END IF;
		
		IF (@rank  = 3) THEN
			
			set @cnt = (SELECT count FROM tbl_rank where rank >= 3 );
			IF (@cnt >2) THEN 
				UPDATE m001 SET rank = 4
				where m001.user_id = @user_id;
			END IF;
		END IF;
		
		IF (@rank  = 4) THEN
			
			set @cnt = (SELECT count FROM tbl_rank where rank >= 4 );
			IF (@cnt >2) THEN 
				UPDATE m001 SET rank = 5
				where m001.user_id = @user_id;
			END IF;
		END IF;
		
		TRUNCATE TABLE tbl_rank;
        -- TRUNCATE TABLE tbl_result;
        
    SET i = i + 1;
	END WHILE;
    
    DROP TEMPORARY TABLE IF EXISTS tbl_tmp;
    DROP TEMPORARY TABLE IF EXISTS tbl_parent;
    DROP TEMPORARY TABLE IF EXISTS tbl_rank;
	DROP TEMPORARY TABLE IF EXISTS tbl_result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wallet_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `wallet_info`(
	IN p_user_id INT,
    IN p_balance DOUBLE(15,8)
)
BEGIN

	IF NOT EXISTS(SELECT 1 FROM w001 WHERE user_id = p_user_id)
    THEN
		INSERT INTO w001 (
			user_id,
            balance_in
        )
        SELECT p_user_id, 0;
    END IF;
    
    
	/*SET @sumgh = (SELECT SUM(amount) FROM d001 WHERE user_id = p_user_id AND  `type` = 2 AND `status` = 1);
	IF EXISTS (SELECT 1 FROM w001 WHERE user_id = p_user_id AND p_balance > 0 AND (withdrawable + @sumgh) <> p_balance ) 
	THEN 
		update w001 
		SET withdrawable = p_balance - @sumgh
		WHERE user_id = p_user_id;
	END IF; 
    */
    update w001 
	SET balance_in = COALESCE(balance_in, 0) + COALESCE(p_balance, 0)
	WHERE user_id = p_user_id;
    
    -- get wallet, coin
	SELECT 
		btc001.user_id,
		btc001.btc_address,
		btc001.btc_label,
        w001.*,
        COALESCE(withdrawable1, 0) + COALESCE(withdrawable2, 0) AS withdrawable, 
        (COALESCE(balance_in, 0) + COALESCE(withdrawable1, 0) + COALESCE(withdrawable2, 0) +COALESCE(sponsor_bonus, 0) + COALESCE(manager_bounus, 0)) AS balance
	FROM
		btc001
	INNER JOIN w001 ON btc001.user_id = w001.user_id
	WHERE btc001.user_id = p_user_id
	AND btc001.del_flag = 0
    AND w001.del_flag = 0
    ;
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `trees`
--

/*!50001 DROP VIEW IF EXISTS `trees`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `trees` AS select `m005`.`tree_id` AS `tree_id`,`m005`.`user_id` AS `user_id`,concat(repeat('',(`m005`.`lvl` - 0)),`m005`.`user_name`) AS `user_name`,`m005`.`description` AS `description`,`m005`.`lvl` AS `lvl`,format((((`m005`.`rht` - `m005`.`lft`) - 1) / 2),0) AS `cnt_children`,(case when ((`m005`.`rht` - `m005`.`lft`) > 1) then 1 else 0 end) AS `is_branch` from `m005` where (`m005`.`lft` >= 1) order by `m005`.`lft` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-24 21:50:13
